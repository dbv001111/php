<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "website");

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Handle user deletion
if (isset($_GET['delete_user'])) {
    $userId = intval($_GET['delete_user']);
    
    // Bắt đầu transaction
    $conn->begin_transaction();
    
    try {
        // 1. Xóa records từ bảng order_status
        $stmt = $conn->prepare("DELETE FROM order_status WHERE order_reference_id IN (SELECT id FROM orders WHERE user_id = ?)");
        $stmt->bind_param("i", $userId);
        $stmt->execute();

        // 2. Xóa từ bảng orders
        $stmt = $conn->prepare("DELETE FROM orders WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();

        // 3. Xóa từ bảng reviews
        $stmt = $conn->prepare("DELETE FROM reviews WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();

        // 4. Xóa từ bảng customer_info
        $stmt = $conn->prepare("DELETE FROM customer_info WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();

        // 5. Cuối cùng xóa user
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();

        // Commit transaction nếu mọi thứ OK
        $conn->commit();
        
        // Chuyển hướng lại trang quản lý user
        header("Location: manage_users.php");
        exit();
        
    } catch (Exception $e) {
        // Rollback nếu có lỗi
        $conn->rollback();
        echo "<script>alert('Không thể xóa người dùng này. Lỗi: " . $e->getMessage() . "');</script>";
    }
}

// Handle customer information deletion
if (isset($_GET['delete_customer'])) {
    $customerId = intval($_GET['delete_customer']);
    $stmt = $conn->prepare("DELETE FROM customer_info WHERE id = ?");
    $stmt->bind_param("i", $customerId);
    $stmt->execute();
    header("Location: manage_users.php");
    exit();
}

// Handle status updates
if (isset($_POST['status'])) {
    $customerId = intval($_POST['customer_id']);
    $newStatus = $conn->real_escape_string($_POST['status']);
    
    $stmt = $conn->prepare("UPDATE customer_info SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $newStatus, $customerId);
    
    if ($stmt->execute()) {
        header("Location: manage_users.php");
        exit();
    }
}

// Update notes
if (isset($_POST['update_notes'])) {
    $customerId = intval($_POST['customer_id']);
    $notes = $conn->real_escape_string($_POST['notes']);
    
    $stmt = $conn->prepare("UPDATE customer_info SET notes = ? WHERE id = ?");
    $stmt->bind_param("si", $notes, $customerId);
    $stmt->execute();
    
    // Return JSON response for AJAX
    header('Content-Type: application/json');
    echo json_encode(['success' => true]);
    exit();
}

// Fetch users and customer information
$users = $conn->query("SELECT * FROM users ORDER BY id DESC");
$customerInfo = $conn->query("SELECT * FROM customer_info ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý người dùng</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4e73df;
            --primary-dark: #3a56c5;
            --secondary-color: #f8f9fc;
            --text-primary: #5a5c69;
            --text-secondary: #858796;
            --success: #1cc88a;
            --danger: #e74a3b;
            --warning: #f6c23e;
            --info: #36b9cc;
            --border-radius: 0.35rem;
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }
        
        body {
            background: #f8f9fc;
            color: var(--text-primary);
            min-height: 100vh;
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 20px 0;
            height: 100vh;
            position: fixed;
            transition: var(--transition);
            z-index: 100;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .sidebar h2 {
            font-size: 1.2rem;
            margin-bottom: 30px;
            padding: 0 20px;
            text-align: center;
            position: relative;
            padding-bottom: 15px;
        }
        
        .sidebar h2:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 60%;
            height: 1px;
            background: rgba(255,255,255,0.3);
        }
        
        .sidebar nav {
            display: flex;
            flex-direction: column;
        }
        
        .sidebar a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: var(--transition);
            border-left: 3px solid transparent;
        }
        
        .sidebar a:hover, .sidebar a.active {
            background-color: rgba(255,255,255,0.1);
            color: white;
            border-left-color: white;
        }
        
        .sidebar a i {
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            flex: 1;
            padding: 30px;
            margin-left: 260px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            border-bottom: 1px solid #e3e6f0;
            padding-bottom: 20px;
        }
        
        .header h1 {
            font-size: 1.75rem;
            color: var(--text-primary);
        }
        
        .back-button {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            border-radius: var(--border-radius);
            text-decoration: none;
            transition: var(--transition);
        }
        
        .back-button:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }
        
        .tab-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .tab-button {
            padding: 12px 24px;
            background: white;
            color: var(--text-primary);
            border: 1px solid #e3e6f0;
            border-radius: var(--border-radius);
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .tab-button.active {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        
        .tab-button:hover:not(.active) {
            background: var(--secondary-color);
        }
        
        .section {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            padding: 25px;
            margin-bottom: 30px;
            display: none;
        }
        
        .section.active {
            display: block;
        }
        
        .section h2 {
            color: var(--text-primary);
            font-size: 1.3rem;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e3e6f0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e3e6f0;
        }
        
        th {
            background: var(--secondary-color);
            color: var(--text-primary);
            font-weight: 600;
        }
        
        tr:hover {
            background: rgba(0,0,0,0.02);
        }
        
        .action-btn {
            display: inline-block;
            padding: 8px 16px;
            border-radius: var(--border-radius);
            text-decoration: none;
            color: white;
            font-weight: 500;
            transition: var(--transition);
            margin-right: 5px;
        }
        
        .edit-btn {
            background: var(--success);
        }
        
        .delete-btn {
            background: var(--danger);
        }
        
        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 0.125rem 0.25rem 0 rgba(58, 59, 69, 0.2);
        }
        
        .status-select {
            padding: 8px;
            border-radius: var(--border-radius);
            border: 1px solid #d1d3e2;
            width: 100%;
            transition: var(--transition);
        }
        
        .status-select:focus {
            border-color: var(--primary-color);
            outline: none;
        }
        
        .notes-field {
            width: 100%;
            min-height: 60px;
            padding: 10px;
            border: 1px solid #d1d3e2;
            border-radius: var(--border-radius);
            resize: vertical;
            transition: var(--transition);
        }
        
        .notes-field:focus {
            border-color: var(--primary-color);
            outline: none;
        }
        
        .status-indicator {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
        }
        
        .status-new .status-indicator { background-color: var(--warning); }
        .status-contacted .status-indicator { background-color: var(--info); }
        .status-completed .status-indicator { background-color: var(--success); }
        
        .badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .badge-new { 
            background-color: rgba(246, 194, 62, 0.1); 
            color: var(--warning);
        }
        
        .badge-contacted { 
            background-color: rgba(54, 185, 204, 0.1); 
            color: var(--info);
        }
        
        .badge-completed { 
            background-color: rgba(28, 200, 138, 0.1); 
            color: var(--success);
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            
            .sidebar h2 {
                display: none;
            }
            
            .sidebar a span {
                display: none;
            }
            
            .sidebar a {
                justify-content: center;
            }
            
            .sidebar a i {
                margin: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 20px;
            }
            
            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .back-button {
                width: 100%;
                text-align: center;
            }
            
            th, td {
                padding: 10px;
            }
            
            .tab-buttons {
                flex-direction: column;
            }
            
            .tab-button {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
                <a href="admin_dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
                <a href="manage_products.php">
                    <i class="fas fa-hamburger"></i>
                    <span>Quản lý món ăn</span>
                </a>
                <a href="manage_users.php" class="active">
                    <i class="fas fa-users"></i>
                    <span>Quản lý người dùng</span>
                </a>
                <a href="manage_news.php">
                    <i class="fas fa-newspaper"></i>
                    <span>Quản lý tin tức</span>
                </a>
                <a href="statistics.php">
                    <i class="fas fa-chart-bar"></i>
                    <span>Thống kê</span>
                </a>
                <a href="admin_logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Đăng xuất</span>
                </a>
            </nav>
        </div>

        <div class="main-content">
            <div class="header">
                <h1>Quản lý người dùng và thông tin khách hàng</h1>
                <a href="admin_dashboard.php" class="back-button">
                    <i class="fas fa-arrow-left"></i> Về Dashboard
                </a>
            </div>

            <div class="tab-buttons">
                <button id="usersTabBtn" class="tab-button active" onclick="showTab('users')">
                    <i class="fas fa-user-circle"></i> Quản lý người dùng
                </button>
                <button id="customersTabBtn" class="tab-button" onclick="showTab('customers')">
                    <i class="fas fa-address-card"></i> Thông tin liên hệ khách hàng
                </button>
            </div>

            <div id="users-section" class="section active">
                <h2><i class="fas fa-users"></i> Danh sách người dùng</h2>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tên đăng nhập</th>
                                <th>Email</th>
                                <th>Ngày đăng ký</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($user = $users->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['id']); ?></td>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo isset($user['created_at']) ? date('d/m/Y H:i', strtotime($user['created_at'])) : 'N/A'; ?></td>
                                <td>
                                    <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="action-btn edit-btn">
                                        <i class="fas fa-edit"></i> Sửa
                                    </a>
                                    <a href="?delete_user=<?php echo $user['id']; ?>" class="action-btn delete-btn" 
                                       onclick="return confirm('Bạn có chắc chắn muốn xóa người dùng này? Tất cả dữ liệu liên quan đến người dùng này sẽ bị xóa vĩnh viễn.');">
                                       <i class="fas fa-trash-alt"></i> Xóa
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div id="customers-section" class="section">
                <h2><i class="fas fa-address-card"></i> Thông tin liên hệ khách hàng</h2>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Họ và Tên</th>
                                <th>Số Điện Thoại</th>
                                <th>Email</th>
                                <th>Địa Chỉ</th>
                                <th>Trạng Thái</th>
                                <th>Ghi Chú</th>
                                <th>Ngày Gửi</th>
                                <th>Thao Tác</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php while ($customer = $customerInfo->fetch_assoc()): ?>
                            <tr class="status-<?php echo $customer['status']; ?>">
                                <td><?php echo htmlspecialchars($customer['id']); ?></td>
                                <td><?php echo htmlspecialchars($customer['full_name']); ?></td>
                                <td>
                                    <a href="tel:<?php echo htmlspecialchars($customer['phone']); ?>">
                                        <?php echo htmlspecialchars($customer['phone']); ?>
                                    </a>
                                </td>
                                <td>
                                    <a href="mailto:<?php echo htmlspecialchars($customer['email']); ?>">
                                        <?php echo htmlspecialchars($customer['email']); ?>
                                    </a>
                                </td>
                                <td><?php echo htmlspecialchars($customer['address']); ?></td>
                                <td>
                                    <form method="POST" action="">
                                        <input type="hidden" name="customer_id" value="<?php echo $customer['id']; ?>">
                                        <select name="status" class="status-select" onchange="this.form.submit()">
                                            <option value="new" <?php echo $customer['status'] == 'new' ? 'selected' : ''; ?>>
                                                <span class="status-indicator"></span> Mới
                                            </option>
                                            <option value="contacted" <?php echo $customer['status'] == 'contacted' ? 'selected' : ''; ?>>
                                                <span class="status-indicator"></span> Đã Liên Hệ
                                            </option>
                                            <option value="completed" <?php echo $customer['status'] == 'completed' ? 'selected' : ''; ?>>
                                                <span class="status-indicator"></span> Hoàn Thành
                                            </option>
                                        </select>
                                    </form>
                                </td>
                                <td>
                                    <textarea class="notes-field" data-id="<?php echo $customer['id']; ?>"><?php echo htmlspecialchars($customer['notes'] ?? ''); ?></textarea>
                                </td>
                                <td><?php echo date('d/m/Y H:i', strtotime($customer['created_at'])); ?></td>
                                <td>
                                    <a href="?delete_customer=<?php echo $customer['id']; ?>" class="action-btn delete-btn"
                                       onclick="return confirm('Bạn có chắc chắn muốn xóa thông tin này?');">
                                       <i class="fas fa-trash-alt"></i> Xóa
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
    function showTab(tabName) {
        // Hide all sections
        document.getElementById('users-section').classList.remove('active');
        document.getElementById('customers-section').classList.remove('active');
        
        // Remove active class from all tab buttons
        document.getElementById('usersTabBtn').classList.remove('active');
        document.getElementById('customersTabBtn').classList.remove('active');
        
        // Show selected section and activate tab button
        if (tabName === 'users') {
            document.getElementById('users-section').classList.add('active');
            document.getElementById('usersTabBtn').classList.add('active');
        } else if (tabName === 'customers') {
            document.getElementById('customers-section').classList.add('active');
            document.getElementById('customersTabBtn').classList.add('active');
        }
    }

    // Setup auto-save for notes fields
    document.addEventListener('DOMContentLoaded', function() {
        const notesFields = document.querySelectorAll('.notes-field');
        
        notesFields.forEach(textarea => {
            textarea.addEventListener('blur', function() {
                const customerId = this.dataset.id;
                const notes = this.value;
                
                // Send AJAX request to update notes
                const formData = new FormData();
                formData.append('customer_id', customerId);
                formData.append('notes', notes);
                formData.append('update_notes', '1');
                
                fetch('manage_users.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Show a quick visual confirmation
                        this.style.borderColor = '#1cc88a';
                        setTimeout(() => {
                            this.style.borderColor = '#d1d3e2';
                        }, 1000);
                    }
                })
                .catch(error => {
                    console.error('Error updating notes:', error);
                    this.style.borderColor = '#e74a3b';
                });
            });
        });
    });
    </script>
</body>
</html>

<?php
$conn->close();
?>