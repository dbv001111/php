<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Kết nối đến cơ sở dữ liệu
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "website";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
$notification = ""; // Biến lưu thông báo

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Kiểm tra người dùng
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $username;
            $_SESSION['logged_in'] = true;

            // Khôi phục giỏ hàng từ cơ sở dữ liệu
            if (!empty($user['cart_data'])) {
                $_SESSION['cart'] = json_decode($user['cart_data'], true);
            } else {
                $_SESSION['cart'] = [];
            }

            $notification = '<div class="notification notification-success">
                <span class="notification-icon">✓</span>
                <span class="notification-text">Đăng nhập thành công!</span>
                <span class="notification-close" onclick="this.parentElement.remove()">✕</span>
            </div>';
            
            // Chuyển hướng sau 2 giây
            echo "<script>
                    setTimeout(function() {
                        window.location.href = 'index.php';
                    }, 2000);
                  </script>";
        } else {
            $notification = '<div class="notification notification-error">
                <span class="notification-icon">⚠️</span>
                <span class="notification-text">Sai mật khẩu!</span>
                <span class="notification-close" onclick="this.parentElement.remove()">✕</span>
            </div>';
        }
    } else {
        $notification = '<div class="notification notification-error">
            <span class="notification-icon">⚠️</span>
            <span class="notification-text">Tài khoản không tồn tại!</span>
            <span class="notification-close" onclick="this.parentElement.remove()">✕</span>
        </div>';
    }
}

// Đóng kết nối
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food and Furious - Đăng Nhập</title>
    <link rel="icon" href="uploads/logo FnF.png">
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="css/notifications.css">
    <style>
        /* Nếu bạn muốn thêm CSS inline thay vì dùng file riêng */
        .notification {
            padding: 15px 20px;
            margin: 20px auto;
            border-radius: 8px;
            font-weight: 500;
            text-align: center;
            max-width: 90%;
            position: relative;
            animation: slideDown 0.5s ease-out forwards;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .notification-success {
            background-color: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }

        .notification-error {
            background-color: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }

        .notification-info {
            background-color: #d1ecf1;
            color: #0c5460;
            border-left: 4px solid #17a2b8;
        }

        .notification-icon {
            margin-right: 10px;
            font-size: 1.5em;
        }

        .notification-text {
            flex-grow: 1;
        }

        .notification-close {
            cursor: pointer;
            font-size: 1.2em;
            opacity: 0.7;
            transition: opacity 0.3s;
        }

        .notification-close:hover {
            opacity: 1;
        }

        @keyframes slideDown {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }

        .fade-out {
            animation: fadeOut 0.5s forwards;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-form">
            <h2>Đăng Nhập</h2>
            <?php echo $notification; ?>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="username">Tên đăng nhập</label>
                    <input type="text" id="username" name="username" placeholder="Nhập tên đăng nhập" required>
                </div>
                <div class="form-group">
                    <label for="password">Mật khẩu</label>
                    <input type="password" id="password" name="password" placeholder="Nhập mật khẩu" required>
                </div>
                <button type="submit" class="login-btn">Đăng Nhập</button>
            </form>
            <p class="register-link">Chưa có tài khoản? <a href="dangki.php">Đăng ký ngay</a></p>
            <a href="index.php" class="home-btn">Trở về trang chủ</a>
        </div>
        <div class="login-image">
            <img src="uploads/logo FnF.png" alt="Login Image">
        </div>
    </div>
    
    <script>
        // Auto-hide notifications after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const notifications = document.querySelectorAll('.notification');
            
            notifications.forEach(notification => {
                setTimeout(() => {
                    notification.classList.add('fade-out');
                    setTimeout(() => {
                        notification.remove();
                    }, 500);
                }, 5000);
            });
            
            // Add click event to close buttons
            const closeButtons = document.querySelectorAll('.notification-close');
            closeButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const notification = this.parentElement;
                    notification.classList.add('fade-out');
                    setTimeout(() => {
                        notification.remove();
                    }, 500);
                });
            });
        });
    </script>
</body>
</html>