<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food and Furious</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/taikhoan.css">
    <link rel="icon" href="uploads/logo FnF.png">
</head>
<body>
    <header>
        <img src="uploads/logo FnF.png" alt="Food and Furious" class="logo">
        <span class="brand-name-home">Food and Furious</span>
        <nav>
            <a href="menu.php">Thực Đơn</a>
            <a href="news.php">Tin Tức</a>
            <a href="#promotions">Danh Mục</a>
            <a href="giohang.php">Giỏ Hàng</a>
            <a href="#contact">Liên Hệ</a>          
        </nav>
       
        <div class="auth-buttons">
            <?php if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true): ?>
                <a href="login.php" class="login-btn" id="loginBtn">Đăng nhập để sử dụng</a>
                <a href="dangki.php" class="register-btn" id="registerBtn">Đăng ký</a>
            <?php else: ?>
                <div class="account-icon-container">
                  <i class="account-icon" id="accountIcon">👤</i>
                <div class="account-dropdown" id="accountDropdown">
                 <div class="account-dropdown-content">
                    <a href="account_info.php">Thông Tin Tài Khoản</a>
                     <a href="order_history.php">Lịch Sử Đơn Hàng</a>
                     <a href="account_settings.php">Cài Đặt Tài Khoản</a>
                     </div>
                 </div>
            </div>
                <button type="button" class="logout-button" onclick="window.location.href='logout.php'">
                    Đăng xuất
                </button>
            <?php endif; ?>
        </div>
    </header>

    <div class="hero">
        <div class="hero-content">
            <h1 class="gradient-text">Burger Ngon Số 1</h1>
            <p class="tagline">Thơm ngon đến từng miếng cắn - Giao hàng nhanh trong 30 phút</p>
            
            <ul class="benefits-list">
                <li>100% thịt bò Úc tươi ngon</li>
                <li>Rau củ tươi mới mỗi ngày</li>
                <li>Công thức đặc biệt độc quyền</li>
                <li>Dịch vụ giao hàng chuyên nghiệp</li>
            </ul>

            <div class="features">
                <span class="feature">✓ Free Ship</span>
                <span class="feature">✓ Đặt Hàng 24/7</span>
                <span class="feature">✓ Tích Điểm Ngay</span>
            </div>

            <div class="cta-section">
                <button class="order-now-btn">Đặt Hàng</button>
                <span class="price">Chỉ từ 49.000đ</span>
            </div>
        </div>

        <div class="carousel-container">
            <div class="carousel">
                <div class="carousel-item left">
                    <img src="uploads/comhome.jpg" alt="Food 1">
                </div>
                <div class="carousel-item center">
                    <img src="uploads/comhome.jpg" alt="Food 2">
                </div>
                <div class="carousel-item right">
                    <img src="uploads/comhome.jpg" alt="Food 3">
                </div>
            </div>
        </div>
    </div>

    <section class="menu-section">
        <h2 id="promotions" class="section-title">DANH MỤC MÓN ĂN</h2>
        <div class="menu-grid">
            <div class="menu-item">
                <img src="uploads/uudaihome.jpg" alt="Khuyến Mãi">
                <div class="menu-item-content">
                    <a class="ds" href="menu.php"><h3>Ưu Đãi<span class="arrow">›</span></h3></a>
                </div>
            </div>

            <div class="menu-item">
                <img src="uploads/monmoihome.jpg" alt="Món Mới">
                <div class="menu-item-content">
                    <a class="ds" href="menu.php"><h3>Món Mới <span class="arrow">›</span></h3></a>
                </div>
            </div>

            <div class="menu-item">
                <img src="uploads/cb1nguoihome.jpg" alt="Combo 1 Người">
                <div class="menu-item-content">
                    <a class="ds" href="menu.php"><h3>Combo 1 Người<span class="arrow">›</span></h3></a>
                </div>
            </div>

            <div class="menu-item">
                <img src="uploads/cbnhomhome.jpg" alt="Combo Nhóm">
                <div class="menu-item-content">
                    <a class="ds" href="menu.php"><h3>Combo Nhóm <span class="arrow">›</span></h3></a>
                </div>
            </div>

            <div class="menu-item">
                <img src="uploads/garanhome.jpg" alt="Gà Rán">
                <div class="menu-item-content">
                    <a class="ds" href="menu.php"><h3>Gà rán <span class="arrow">›</span></h3></a>
                </div>
            </div>

            <div class="menu-item">
                <img src="uploads/comhome.jpg" alt="Cơm">
                <div class="menu-item-content">
                    <a class="ds" href="menu.php"><h3>Cơm & Burger<span class="arrow">›</span></h3></a>
                </div>
            </div>

            <div class="menu-item">
                <img src="uploads/annhehome.jpg" alt="Món Ăn Nhẹ">
                <div class="menu-item-content">
                    <a class="ds" href="menu.php"><h3>Món Ăn Nhẹ<span class="arrow">›</span></h3></a>
                </div>
            </div>

            <div class="menu-item">
                <img src="uploads/trangmienghome.jpg" alt="Tráng Miệng">
                <div class="menu-item-content">
                    <a class="ds" href="menu.php"><h3>Tráng Miệng <span class="arrow">›</span></h3></a>
                </div>
            </div>
        </div>
    </section>

    <section class="customer-info-section">
        <h2>Để Lại Thông Tin Của Bạn</h2>
        <p>Vui lòng điền thông tin bên dưới để chúng tôi có thể phục vụ bạn tốt nhất:</p>
        
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_info'])) {
            $conn = new mysqli("localhost", "root", "", "website");
            
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            
            $full_name = $conn->real_escape_string($_POST['full_name']);
            $phone = $conn->real_escape_string($_POST['phone_number']);
            $email = $conn->real_escape_string($_POST['email']);
            $address = $conn->real_escape_string($_POST['address']);
            
            $sql = "INSERT INTO customer_info (full_name, phone, email, address) 
                    VALUES (?, ?, ?, ?)";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssss", $full_name, $phone, $email, $address);
            
            if ($stmt->execute()) {
                echo '<div class="success-message">Cảm ơn bạn đã để lại thông tin. Chúng tôi sẽ liên hệ với bạn sớm nhất!</div>';
            } else {
                echo '<div class="error-message">Có lỗi xảy ra. Vui lòng thử lại sau.</div>';
            }
            
            $stmt->close();
            $conn->close();
        }
        ?>
        
        <form class="customer-info-form" method="POST" action="">
            <div class="form-group">
                <label for="full-name">Họ và Tên:</label>
                <input type="text" id="full-name" name="full_name" required>
            </div>
            <div class="form-group">
                <label for="phone-number">Số Điện Thoại:</label>
                <input type="tel" id="phone-number" name="phone_number" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="address">Địa Chỉ:</label>
                <input type="text" id="address" name="address" required>
            </div>
            <button type="submit" name="submit_info" class="submit-btn">Gửi Thông Tin</button>
        </form>
    </section>

    <footer id="contact">
        <div class="footer-container">
            <div class="footer-section">
                <h3>Thông Tin Liên Hệ</h3>
                <ul>
                    <li>Địa chỉ: số 48, ngõ 73 đường kim chung, yên vĩnh, hoài đức, hà nội</li>
                    <li>Số điện thoại: 0363102985</li>
                    <li>Email: 20221568@eaut.edu.vn</li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Chính Sách</h3>
                <ul>
                    <li>Chính sách bảo mật</li>
                    <li>Chính sách giao hàng</li>
                    <li>Chính sách đổi trả</li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Mạng Xã Hội</h3>
                <ul>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Instagram</a></li>
                    <li><a href="#">Twitter</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-copyright">
            <p>&copy; 2024 Food and Furious. All rights reserved.</p>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const accountIcon = document.getElementById('accountIcon');
            const accountDropdown = document.getElementById('accountDropdown');
            
            if (accountIcon && accountDropdown) {
                accountIcon.addEventListener('click', function(e) {
                    e.stopPropagation();
                    accountDropdown.style.display = accountDropdown.style.display === 'block' ? 'none' : 'block';
                });

                document.addEventListener('click', function() {
                    accountDropdown.style.display = 'none';
                });

                accountDropdown.addEventListener('click', function(e) {
                    e.stopPropagation();
                });
            }
        });

        document.addEventListener('DOMContentLoaded', function() {
            const items = document.querySelectorAll('.carousel-item');
            const positions = ['left', 'center', 'right'];
            let currentIndex = 0;

            function updateCarousel() {
                items.forEach((item, index) => {
                    const newPosition = (index - currentIndex + positions.length) % positions.length;
                    item.className = `carousel-item ${positions[newPosition]}`;
                });
                
                currentIndex = (currentIndex + 1) % items.length;
            }

            setInterval(updateCarousel, 5000);
        });
    </script>
    <script>
        // Thay đổi phần JavaScript trong index.php
document.addEventListener('DOMContentLoaded', function() {
    const accountIcon = document.getElementById('accountIcon');
    const accountDropdown = document.getElementById('accountDropdown');
    
    if (accountIcon && accountDropdown) {
        accountIcon.addEventListener('click', function(e) {
            e.stopPropagation();
            accountDropdown.classList.toggle('show');
        });

        // Đóng dropdown khi click bên ngoài
        document.addEventListener('click', function(e) {
            if (!accountIcon.contains(e.target) && !accountDropdown.contains(e.target)) {
                accountDropdown.classList.remove('show');
            }
        });

        // Ngăn chặn đóng dropdown khi click vào nội dung dropdown
        accountDropdown.addEventListener('click', function(e) {
            e.stopPropagation();
        });
    }
});
    </script>
</body>
</html>