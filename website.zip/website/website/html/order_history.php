<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Xử lý hủy đơn hàng
if (isset($_POST['cancel_order'])) {
    $order_id = $_POST['order_id'];
    
    // Kiểm tra xem đơn hàng có thuộc về user hiện tại không
    $check_stmt = $conn->prepare("SELECT * FROM order_status WHERE order_id = ? AND payment_status = 0");
    $check_stmt->bind_param("s", $order_id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Cập nhật trạng thái đơn hàng thành đã hủy
        $update_stmt = $conn->prepare("UPDATE order_status SET status = 'cancelled' WHERE order_id = ?");
        $update_stmt->bind_param("s", $order_id);
        
        if ($update_stmt->execute()) {
            $_SESSION['order_cancelled'] = true;
            $_SESSION['cancelled_order_id'] = $order_id;
        } else {
            $_SESSION['order_cancelled'] = false;
            $_SESSION['cancel_error'] = "Có lỗi xảy ra khi hủy đơn hàng!";
        }
    } else {
        $_SESSION['order_cancelled'] = false;
        $_SESSION['cancel_error'] = "Không thể hủy đơn hàng này!";
    }
}

// Lấy thông tin đơn hàng
$sql = "SELECT o.id, o.order_date, o.quantity, 
        os.order_id, os.payment_method, os.total_amount, os.shipping_address, os.payment_status, os.status,
        p.name as product_name, p.price
        FROM orders o
        JOIN products p ON o.product_id = p.id
        JOIN order_status os ON o.id = os.order_reference_id
        WHERE o.user_id = ?
        ORDER BY o.order_date DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Lịch Sử Đơn Hàng</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .cancel-btn {
            background-color: #dc3545;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .cancel-btn:hover {
            background-color: #c82333;
            transform: translateY(-2px);
        }
        
        .cancel-btn:disabled {
            background-color: #6c757d;
            cursor: not-allowed;
        }
        
        .status-cancelled {
            color: #dc3545;
            font-weight: bold;
        }
        
        .status-completed {
            color: #28a745;
            font-weight: bold;
        }
        
        .status-pending {
            color: #ffc107;
            font-weight: bold;
        }
        
        /* Notification styles */
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            display: flex;
            align-items: center;
            min-width: 300px;
            max-width: 400px;
            transform: translateX(150%);
            transition: transform 0.4s ease;
        }
        
        .notification.show {
            transform: translateX(0);
        }
        
        .notification-success {
            background-color: #4CAF50;
            color: white;
        }
        
        .notification-error {
            background-color: #ff3333;
            color: white;
        }
        
        .notification-icon {
            margin-right: 15px;
            font-size: 20px;
        }
        
        .notification-message {
            flex-grow: 1;
        }
        
        .notification-close {
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            margin-left: 10px;
            opacity: 0.8;
            transition: opacity 0.3s ease;
        }
        
        .notification-close:hover {
            opacity: 1;
        }
        
        .animation-shake {
            animation: shake 0.82s cubic-bezier(.36,.07,.19,.97) both;
        }
        
        @keyframes shake {
            10%, 90% {
                transform: translateX(-1px);
            }
            20%, 80% {
                transform: translateX(2px);
            }
            30%, 50%, 70% {
                transform: translateX(-4px);
            }
            40%, 60% {
                transform: translateX(4px);
            }
        }
    </style>
</head>
<body>
    <div class="order-history-container">
        <h2>Lịch Sử Đơn Hàng</h2>
        <?php if ($result->num_rows > 0): ?>
            <table class="order-table">
                <thead>
                    <tr>
                        <th>Mã đơn hàng</th>
                        <th>Ngày đặt</th>
                        <th>Sản phẩm</th>
                        <th>Số lượng</th>
                        <th>Phương thức thanh toán</th>
                        <th>Địa chỉ giao hàng</th>
                        <th>Tổng tiền</th>
                        <th>Trạng thái</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($order = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($order['order_id']); ?></td>
                            <td><?php echo date('d/m/Y H:i', strtotime($order['order_date'])); ?></td>
                            <td><?php echo htmlspecialchars($order['product_name']); ?></td>
                            <td><?php echo $order['quantity']; ?></td>
                            <td><?php echo htmlspecialchars($order['payment_method']); ?></td>
                            <td><?php echo htmlspecialchars($order['shipping_address']); ?></td>
                            <td><?php echo number_format($order['total_amount'], 0, ',', '.') . 'đ'; ?></td>
                            <td class="<?php 
                                if ($order['status'] == 'cancelled') echo 'status-cancelled';
                                elseif ($order['payment_status']) echo 'status-completed';
                                else echo 'status-pending';
                            ?>">
                                <?php 
                                if ($order['status'] == 'cancelled') echo 'Đã hủy';
                                elseif ($order['payment_status']) echo 'Đã thanh toán';
                                else echo 'Chờ thanh toán';
                                ?>
                            </td>
                            <td>
                                <?php if (!$order['payment_status'] && $order['status'] != 'cancelled'): ?>
                                    <form method="POST" onsubmit="return confirmCancel('<?php echo htmlspecialchars($order['order_id']); ?>');">
                                        <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                        <button type="submit" name="cancel_order" class="cancel-btn">
                                            <i class="fas fa-times-circle"></i> Hủy đơn
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Bạn chưa có đơn hàng nào.</p>
        <?php endif; ?>
        <a href="index.php" class="back-btn">Quay lại trang chủ</a>
    </div>
    
    <!-- Notification Components -->
    <div id="successNotification" class="notification notification-success">
        <span class="notification-icon"><i class="fas fa-check-circle"></i></span>
        <span class="notification-message">Hủy đơn hàng thành công!</span>
        <button class="notification-close" onclick="closeNotification('successNotification')">&times;</button>
    </div>
    
    <div id="errorNotification" class="notification notification-error">
        <span class="notification-icon"><i class="fas fa-exclamation-circle"></i></span>
        <span id="errorMessage" class="notification-message">Đã xảy ra lỗi!</span>
        <button class="notification-close" onclick="closeNotification('errorNotification')">&times;</button>
    </div>

    <script>
    function confirmCancel(orderId) {
        return confirm('Bạn có chắc chắn muốn hủy đơn hàng #' + orderId + '?');
    }
    
    function showNotification(id, message = null) {
        const notification = document.getElementById(id);
        if (message && id === 'errorNotification') {
            document.getElementById('errorMessage').textContent = message;
        }
        notification.classList.add('show');
        
        // Add shake animation for error notification
        if (id === 'errorNotification') {
            notification.classList.add('animation-shake');
            setTimeout(() => {
                notification.classList.remove('animation-shake');
            }, 1000);
        }
        
        // Auto close after 5 seconds
        setTimeout(() => {
            closeNotification(id);
        }, 5000);
    }
    
    function closeNotification(id) {
        const notification = document.getElementById(id);
        notification.classList.remove('show');
    }
    
    // Check for session notifications
    document.addEventListener('DOMContentLoaded', function() {
        <?php if (isset($_SESSION['order_cancelled'])): ?>
            <?php if ($_SESSION['order_cancelled']): ?>
                showNotification('successNotification');
            <?php else: ?>
                showNotification('errorNotification', '<?php echo isset($_SESSION['cancel_error']) ? $_SESSION['cancel_error'] : "Không thể hủy đơn hàng!"; ?>');
            <?php endif; ?>
            <?php 
            // Clear notification flags
            unset($_SESSION['order_cancelled']);
            unset($_SESSION['cancel_error']);
            ?>
        <?php endif; ?>
    });
    </script>
</body>
</html>