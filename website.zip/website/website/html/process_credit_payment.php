<?php
session_start();
$conn = new mysqli("localhost", "root", "", "website");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = 'ORD' . time();
    $shipping_address = $_POST['shipping_address'];
    $total_amount = $_SESSION['total_amount'];
    
    $stmt = $conn->prepare("INSERT INTO orders (order_id, payment_method, total_amount, shipping_address, order_date) VALUES (?, 'Payment Method', ?, ?, NOW())");
    $stmt->bind_param("sds", $order_id, $total_amount, $shipping_address);
    
    if ($stmt->execute()) {
        $_SESSION['last_order_id'] = $order_id;
        $_SESSION['cart'] = array();
        $_SESSION['quantity'] = array();
        header("Location: giohang.php?payment=success");
    } else {
        header("Location: giohang.php?payment=failed");
    }
}

$conn->close();

?>