/* process_bank_payment.php - Cập nhật trạng thái thanh toán */
<?php
session_start();
$conn = new mysqli("localhost", "root", "", "website");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['total_amount']) || empty($_SESSION['total_amount'])) {
        die("Lỗi: Không có tổng số tiền trong session");
    }
    
    $order_id = 'ORD' . time();
    $shipping_address = isset($_POST['shipping_address']) ? $_POST['shipping_address'] : '';
    $total_amount = $_SESSION['total_amount'];
    
    if (empty($shipping_address)) {
        die("Lỗi: Địa chỉ giao hàng không được để trống");
    }
    
    $stmt = $conn->prepare("INSERT INTO orders (order_id, payment_method, total_amount, shipping_address, order_date) VALUES (?, 'Payment Method', ?, ?, NOW())");
    $stmt->bind_param("sds", $order_id, $total_amount, $shipping_address);
    
    if ($stmt->execute()) {
        $_SESSION['last_order_id'] = $order_id;
        $_SESSION['cart'] = array();
        $_SESSION['quantity'] = array();
        header("Location: bank.php?order_id=$order_id");
        exit();
    } else {
        die("Lỗi khi lưu đơn hàng: " . $stmt->error);
    }
}
$conn->close();
?>