<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $searchQuery = '';
    if (isset($_GET['search'])) {
        $searchQuery = $_GET['search'];
    }

    // Handle add to cart action via AJAX
    if(isset($_POST['ajax_add_to_cart']) && isset($_POST['product_id'])) {
        $product_id = (int)$_POST['product_id'];
        
        // Add product to cart logic
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
        if (!in_array($product_id, $_SESSION['cart'])) {
            $_SESSION['cart'][] = $product_id;
            $_SESSION['quantity'][$product_id] = 1;
        }
        
        // Get product name for the notification
        $stmt = $pdo->prepare("SELECT name FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch();
        
        echo json_encode([
            'status' => 'success',
            'message' => 'Đã thêm ' . $product['name'] . ' vào giỏ hàng!'
        ]);
        exit;
    }
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food and Furious - Menu</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/menu.css">
    <link rel="stylesheet" href="css/rating.css">
    <style>
        /* Keep all existing styles */
        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
        }

        .header-left {
            display: flex;
            align-items: center;
        }

        .header-left .logo {
            margin-right: 20px;
        }

        .header-center {
            flex-grow: 1;
            text-align: center;
        }

        .header-right {
            display: flex;
            align-items: center;
        }

        .search-form {
            display: flex;
            align-items: center;
        }

        .search-form input[type="text"] {
            padding: 10px;
            border: 2px solid #FF4B4B;
            border-radius: 20px 0 0 20px;
            outline: none;
            width: 250px;
            transition: border-color 0.3s;
        }

        .search-form button {
            padding: 10px 15px;
            background-color: #FF4B4B;
            color: white;
            border: none;
            border-radius: 0 20px 20px 0;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .navigation {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-top: 25px;
        }

        .nav-button {
            background: #FF4B4B;
            color: white;
            padding: 12px 30px;
            text-decoration: none;
            border-radius: 25px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .nav-button:hover {
            background: #FF3333;
        }

        .add-to-cart-button {
            background-color: #FF4B4B;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 10px;
            text-decoration: none;
            display: inline-block;
        }

        .add-to-cart-button:hover {
            background-color: #FF1A1A;
        }
        
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
        }
        
        .success-notification {
            background-color: #4CAF50;
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            display: flex;
            align-items: center;
            min-width: 300px;
            animation: slideIn 0.3s, fadeOut 0.5s 2.5s forwards;
            overflow: hidden;
        }
        
        .success-icon {
            margin-right: 15px;
            background-color: white;
            color: #4CAF50;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes fadeOut {
            from {
                opacity: 1;
            }
            to {
                opacity: 0;
            }
        }
        
        .rating-toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 15px 25px;
            border-radius: 8px;
            color: white;
            font-weight: bold;
            z-index: 1000;
            animation: slideIn 0.3s ease, fadeOut 0.5s ease 2.5s forwards;
        }

        .rating-toast.success {
            background-color: #28a745;
        }

        .rating-toast.error {
            background-color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div class="header-container">
                <div class="header-left">
                    <div class="logo">
                        <img src="uploads/logo FnF.png" alt="Food and Furious" class="logo-img">
                    </div>
                    <h1>Food and Furious</h1>
                </div>

                <div class="header-center">
                    <div class="navigation">
                        <a href="index.php" class="nav-button">Trang chủ</a>
                        <a href="giohang.php" class="nav-button">Giỏ hàng</a>
                    </div>
                </div>

                <div class="header-right">
                    <form method="GET" action="menu.php" class="search-form">
                        <input type="text" name="search" placeholder="Tìm kiếm món ăn..." 
                               value="<?= htmlspecialchars($searchQuery) ?>">
                        <button type="submit"><i class="fas fa-search"></i></button>
                    </form>
                </div>
            </div>
        </header>

        <main>
            <?php
            $categoriesStmt = $pdo->query("SELECT * FROM categories");
            $categories = $categoriesStmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($categories as $category) {
                $categoryId = $category['id'];
                $categoryName = htmlspecialchars($category['name']);

                echo "<h2 class='category-title'>$categoryName</h2>";
                echo '<div class="products">';

                $stmt = $pdo->prepare("
                    SELECT p.*, 
                           COALESCE(AVG(r.rating), 0) as avg_rating,
                           COUNT(r.id) as review_count
                    FROM products p
                    LEFT JOIN reviews r ON p.id = r.product_id
                    WHERE p.category_id = ? AND p.name LIKE ?
                    GROUP BY p.id
                ");
                $searchPattern = "%$searchQuery%";
                $stmt->execute([$categoryId, $searchPattern]);

                while ($product = $stmt->fetch()) {
                    ?>
                    <div class="product">
                        <img src="<?= htmlspecialchars($product['image']) ?>" 
                             alt="<?= htmlspecialchars($product['name']) ?>"
                             class="product-image">
                        
                        <div class="product-info">
                            <h3 class="product-name"><?= htmlspecialchars($product['name']) ?></h3>
                            
                            <?php if ($product['description']): ?>
                                <p class="product-description">
                                    <?= htmlspecialchars($product['description']) ?>
                                </p>
                            <?php endif; ?>
                            
                            <p class="price"><?= number_format($product['price']) ?>₫</p>
                            
                            <div class="rating-section" data-product-id="<?= $product['id'] ?>">
                                <div class="rating-display">
                                    <div class="stars">
                                        <?php
                                        $rating = round($product['avg_rating']);
                                        for ($i = 1; $i <= 5; $i++) {
                                            echo '<span class="star ' . ($i <= $rating ? 'filled' : '') . '">★</span>';
                                        }
                                        ?>
                                    </div>
                                    <span class="rating-average">
                                        <?= number_format($product['avg_rating'], 1) ?>/5
                                    </span>
                                    <span class="review-count">
                                        (<?= $product['review_count'] ?> đánh giá)
                                    </span>
                                </div>

                                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
                                    <button class="rate-button" 
                                            onclick="showRatingModal(<?= $product['id'] ?>)">
                                        Đánh giá sản phẩm
                                    </button>
                                <?php endif; ?>
                            </div>

                            <div class="product-actions">
                                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
                                    <button type="button" class="add-to-cart-button" 
                                            onclick="addToCart(<?= $product['id'] ?>, '<?= htmlspecialchars(addslashes($product['name'])) ?>')">
                                        <i class="fas fa-shopping-cart"></i> Thêm vào giỏ hàng
                                    </button>
                                <?php else: ?>
                                    <a href="login.php" class="add-to-cart-button"
                                       onclick="return confirm('Vui lòng đăng nhập để đặt hàng!');">
                                        <i class="fas fa-shopping-cart"></i> Đăng nhập để mua hàng
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                echo '</div>';
            }
            ?>
        </main>

        <!-- Rating Modal -->
        <div id="ratingModal" class="rating-modal">
            <div class="modal-content">
                <span class="modal-close">&times;</span>
                <h2 class="modal-title">Đánh giá sản phẩm</h2>
                <form id="ratingForm">
                    <input type="hidden" id="modalProductId" name="product_id">
                    
                    <div class="star-rating">
                        <?php for($i = 5; $i >= 1; $i--): ?>
                            <input type="radio" name="rating" value="<?= $i ?>" 
                                   id="star<?= $i ?>" required>
                            <label for="star<?= $i ?>" title="<?= $i ?> sao">★</label>
                        <?php endfor; ?>
                    </div>
                    
                    <div class="comment-input">
                        <textarea name="comment" 
                                  placeholder="Chia sẻ nhận xét của bạn về sản phẩm (không bắt buộc)"
                                  maxlength="500"></textarea>
                    </div>
                    
                    <button type="submit" class="submit-rating">Gửi đánh giá</button>
                </form>
            </div>
        </div>
        
        <!-- Toast Container for Notifications -->
        <div id="toastContainer" class="toast-container"></div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const ratingModal = document.getElementById('ratingModal');
        const closeModal = document.querySelector('.modal-close');
        let currentProductId = null;

        window.showRatingModal = function(productId) {
            currentProductId = productId;
            document.getElementById('modalProductId').value = productId;
            
            // Kiểm tra xem người dùng đã đánh giá sản phẩm này chưa
            fetch(`laydanhgia.php?product_id=${productId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success' && data.rating) {
                        // Chọn sẵn đánh giá trước đó của người dùng
                        document.querySelector(`#star${data.rating}`).checked = true;
                        
                        if (data.comment) {
                            document.querySelector('textarea[name="comment"]').value = data.comment;
                        }
                    } else {
                        // Reset form cho đánh giá mới
                        document.getElementById('ratingForm').reset();
                    }
                    ratingModal.style.display = 'block';
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('ratingForm').reset();
                    ratingModal.style.display = 'block';
                });
        }

        closeModal.onclick = function() {
            ratingModal.style.display = 'none';
        }

        window.onclick = function(event) {
            if (event.target === ratingModal) {
                ratingModal.style.display = 'none';
            }
        }

        document.getElementById('ratingForm').onsubmit = function(e) {
            e.preventDefault();
            const formData = new FormData(this);

            fetch('rate_product.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    const ratingSection = document.querySelector(
                        `.rating-section[data-product-id="${currentProductId}"]`
                    );
                    const stars = ratingSection.querySelectorAll('.star');
                    const rating = Math.round(parseFloat(data.new_rating));
                    
                    stars.forEach((star, index) => {
                        star.classList.toggle('filled', index < rating);
                    });
                    
                    ratingSection.querySelector('.rating-average').textContent = 
                        `${data.new_rating}/5`;
                    ratingSection.querySelector('.review-count').textContent = 
                        `(${data.review_count} đánh giá)`;
                    
                    ratingModal.style.display = 'none';
                    
                    const toast = document.createElement('div');
                    toast.className = 'rating-toast success';
                    toast.textContent = 'Cảm ơn bạn đã đánh giá!';
                    document.body.appendChild(toast);
                    
                    setTimeout(() => {
                        toast.remove();
                    }, 3000);
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Có lỗi xảy ra, vui lòng thử lại sau.');
            });
        };
        
        // Thêm chức năng Thêm vào giỏ hàng với AJAX
        window.addToCart = function(productId, productName) {
            const formData = new FormData();
            formData.append('ajax_add_to_cart', '1');
            formData.append('product_id', productId);
            
            fetch('menu.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    showSuccessNotification(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                // Fallback if AJAX fails - still show the notification
                showSuccessNotification(`Đã thêm sản phẩm vào giỏ hàng!`);
            });
        };
        
        // Function to show success notification
        function showSuccessNotification(message) {
            const toastContainer = document.getElementById('toastContainer');
            
            const notification = document.createElement('div');
            notification.className = 'success-notification';
            
            const icon = document.createElement('span');
            icon.className = 'success-icon';
            icon.innerHTML = '✓';
            
            const text = document.createElement('span');
            text.textContent = message;
            
            notification.appendChild(icon);
            notification.appendChild(text);
            toastContainer.appendChild(notification);
            
            // Remove the notification after 3 seconds
            setTimeout(() => {
                notification.style.animation = 'fadeOut 0.5s forwards';
                setTimeout(() => {
                    notification.remove();
                }, 500);
            }, 3000);
        }
    });
    </script>
</body>
</html>

<?php
} catch(PDOException $e) {
    echo "Kết nối thất bại: " . $e->getMessage();
}
?>