<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$notification = ""; // Biến lưu thông báo

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $servername = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "website";

    try {
        $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

        if ($conn->connect_error) {
            throw new Exception("Kết nối thất bại: " . $conn->connect_error);
        }

        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);
        $confirmPassword = trim($_POST['confirm-password']);

        // Validate input
        if (strlen($username) < 3) {
            throw new Exception("Tên đăng nhập phải có ít nhất 3 ký tự!");
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Email không hợp lệ!");
        }

        if (strlen($password) < 6) {
            throw new Exception("Mật khẩu phải có ít nhất 6 ký tự!");
        }

        if ($password !== $confirmPassword) {
            throw new Exception("Mật khẩu xác nhận không khớp!");
        }

        // Check existing username
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            throw new Exception("Tên đăng nhập đã tồn tại!");
        }

        // Check existing email
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            throw new Exception("Email đã được sử dụng!");
        }

        // Hash password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Insert new user
        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashedPassword);

        if ($stmt->execute()) {
            $notification = '<div class="notification notification-success">
                <span class="notification-icon">✅</span>
                <span class="notification-text">Đăng ký thành công! Vui lòng đăng nhập.</span>
                <span class="notification-close" onclick="this.parentElement.remove()">✕</span>
            </div>';
            
            // Redirect sau 2 giây
            echo "<script>
                    setTimeout(function() {
                        window.location.href = 'login.php';
                    }, 2000);
                  </script>";
        } else {
            throw new Exception("Lỗi khi đăng ký: " . $stmt->error);
        }

    } catch (Exception $e) {
        $notification = '<div class="notification notification-error">
            <span class="notification-icon">⚠️</span>
            <span class="notification-text">Lỗi: ' . $e->getMessage() . '</span>
            <span class="notification-close" onclick="this.parentElement.remove()">✕</span>
        </div>';
    } finally {
        if (isset($conn)) {
            $conn->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food and Furious - Đăng Ký</title>
    <link rel="icon" href="uploads/logo FnF.png">
    <link rel="stylesheet" href="css/dangki.css">
    <link rel="stylesheet" href="css/notifications.css">
    <style>
        /* Nếu bạn muốn thêm CSS inline thay vì dùng file riêng */
        .notification {
            padding: 15px 20px;
            margin: 20px auto;
            border-radius: 8px;
            font-weight: 500;
            text-align: center;
            max-width: 90%;
            position: relative;
            animation: slideDown 0.5s ease-out forwards;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .notification-success {
            background-color: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }

        .notification-error {
            background-color: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }

        .notification-info {
            background-color: #d1ecf1;
            color: #0c5460;
            border-left: 4px solid #17a2b8;
        }

        .notification-icon {
            margin-right: 10px;
            font-size: 1.5em;
        }

        .notification-text {
            flex-grow: 1;
        }

        .notification-close {
            cursor: pointer;
            font-size: 1.2em;
            opacity: 0.7;
            transition: opacity 0.3s;
        }

        .notification-close:hover {
            opacity: 1;
        }

        @keyframes slideDown {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }

        .fade-out {
            animation: fadeOut 0.5s forwards;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <div class="login-form">
            <h2>Đăng Ký</h2>
            <?php echo $notification; ?>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="username">Tên đăng nhập</label>
                    <input type="text" id="username" name="username" placeholder="Nhập tên đăng nhập" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="Nhập địa chỉ email" required>
                </div>
                <div class="form-group">
                    <label for="password">Mật khẩu</label>
                    <input type="password" id="password" name="password" placeholder="Nhập mật khẩu" required>
                </div>
                <div class="form-group">
                    <label for="confirm-password">Xác nhận mật khẩu</label>
                    <input type="password" id="confirm-password" name="confirm-password" placeholder="Xác nhận mật khẩu" required>
                </div>
                <button type="submit" class="login-btn">Đăng Ký</button>
            </form>
            <p class="register-link">Đã có tài khoản? <a href="login.php">Đăng nhập ngay</a></p>
            <a href="index.php" class="home-btn">Trở về trang chủ</a>
        </div>
        <div class="login-image">
            <img src="uploads/logo FnF.png" alt="Register Image">
        </div>
    </div>
    
    <script>
        // Auto-hide notifications after 5 seconds (except for success messages when registering)
        document.addEventListener('DOMContentLoaded', function() {
            const errorNotifications = document.querySelectorAll('.notification-error');
            
            errorNotifications.forEach(notification => {
                setTimeout(() => {
                    notification.classList.add('fade-out');
                    setTimeout(() => {
                        notification.remove();
                    }, 500);
                }, 5000);
            });
            
            // Add click event to close buttons
            const closeButtons = document.querySelectorAll('.notification-close');
            closeButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const notification = this.parentElement;
                    notification.classList.add('fade-out');
                    setTimeout(() => {
                        notification.remove();
                    }, 500);
                });
            });
        });
    </script>
</body>
</html>