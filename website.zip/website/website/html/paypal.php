<?php
session_start();

// Kiểm tra nếu giỏ hàng không rỗng
if (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0) {
    echo '<p>Giỏ hàng của bạn đang trống.</p>';
    exit();
}

$total_amount = isset($_SESSION['total_amount']) ? $_SESSION['total_amount'] : 0;

// Kết nối đến cơ sở dữ liệu
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $order_id = 'ORD' . time(); // Tạo mã đơn hàng
        $shipping_address = $_POST['shipping_address'];

        if (empty($shipping_address)) {
            die("Lỗi: Địa chỉ giao hàng không được để trống");
        }

        $pdo->beginTransaction();

        try {
            // Thêm vào bảng orders cho từng sản phẩm trong giỏ hàng 
            foreach($_SESSION['cart'] as $product_id) {
                if (isset($_SESSION['quantity'][$product_id])) { // Thêm kiểm tra tồn tại
                    $quantity = $_SESSION['quantity'][$product_id];
                    
                    // Kiểm tra và chuyển đổi kiểu dữ liệu
                    $user_id = (int)$_SESSION['user_id'];
                    $product_id = (int)$product_id;
                    $quantity = (int)$quantity;

                    $stmt = $pdo->prepare("INSERT INTO orders (user_id, product_id, quantity) VALUES (?, ?, ?)");
                    $stmt->execute([$user_id, $product_id, $quantity]);
                    $order_reference_id = $pdo->lastInsertId();
                    
                    // Thêm vào bảng order_status
                    $payment_method = 'PayPal';
                    $stmt = $pdo->prepare("INSERT INTO order_status (order_id, order_reference_id, payment_method, total_amount, shipping_address, payment_status) VALUES (?, ?, ?, ?, ?, 0)");
                    $stmt->execute([$order_id, $order_reference_id, $payment_method, $total_amount, $shipping_address]);
                }
            }

            $pdo->commit();
            $_SESSION['last_order_id'] = $order_id;
            $_SESSION['cart'] = array();
            $_SESSION['quantity'] = array();
            $_SESSION['payment_success'] = true;
            
            // Redirect to success page
            header("Location: payment_success.php?method=paypal");
            exit();
        } catch (Exception $e) {
            $pdo->rollBack();
            die("Lỗi khi lưu đơn hàng: " . $e->getMessage());
        }
    }
} catch(PDOException $e) {
    echo "Kết nối thất bại: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanh Toán Qua PayPal</title>
    <link rel="stylesheet" href="css/paypal.css">
</head>
<body>
    <div class="container">
        <h1>Thanh Toán Qua PayPal</h1>
        
        <form method="POST" action="">
            <div class="input-field">
                <label for="paypal_email">Email PayPal</label>
                <input type="email" id="paypal_email" name="paypal_email" required
                       placeholder="email@example.com">
            </div>
            
            <div class="input-field">
                <label for="paypal_password">Mật khẩu PayPal</label>
                <input type="password" id="paypal_password" name="paypal_password" required
                       placeholder="Nhập mật khẩu PayPal">
            </div>

            <div class="input-field">
                <label for="shipping_address">Địa chỉ giao hàng</label>
                <input type="text" id="shipping_address" name="shipping_address" required 
                       placeholder="Nhập địa chỉ giao hàng của bạn">
            </div>

            <button type="submit" class="btn">Xác nhận thanh toán</button>
            <a href="giohang.php" class="btn back-btn">Trở về Giỏ hàng</a>
        </form>

        <div class="total-amount">
            Tổng số tiền: <?php echo number_format($total_amount); ?> VNĐ
        </div>
    </div>
</body>
</html>