<?php
session_start();

// Kiểm tra nếu giỏ hàng không rỗng
if (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0) {
    echo '<p>Giỏ hàng của bạn đang trống.</p>';
    exit();
}

// Giả sử thanh toán thành công
header('Location: success.php');
exit();