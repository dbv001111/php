<?php
session_start();

if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    $userId = $_SESSION['user_id']; // ID người dùng từ session
    $cartItems = json_encode($_SESSION['cart']); // Chuyển giỏ hàng thành JSON

    // Kết nối đến cơ sở dữ liệu
    $conn = new mysqli("localhost", "root", "", "website");

    // Lưu giỏ hàng vào cơ sở dữ liệu
    $stmt = $conn->prepare("UPDATE users SET cart_data = ? WHERE id = ?");
    $stmt->bind_param("si", $cartItems, $userId);
    $stmt->execute();
}

// Xóa tất cả các biến session
$_SESSION = array();
session_destroy();

header("Location: index.php");
exit();
?>