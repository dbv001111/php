<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "website");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Thống kê doanh thu ngày
$daily_revenue = $conn->query("
    SELECT SUM(total_amount) as revenue, COUNT(*) as orders
    FROM order_status 
    WHERE payment_status = 1 
    AND DATE(order_date) = CURDATE()
")->fetch_assoc();

// Thống kê doanh thu tuần
$weekly_revenue = $conn->query("
    SELECT SUM(total_amount) as revenue, COUNT(*) as orders
    FROM order_status 
    WHERE payment_status = 1 
    AND order_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
")->fetch_assoc();

// Thống kê doanh thu tháng
$monthly_revenue = $conn->query("
    SELECT SUM(total_amount) as revenue, COUNT(*) as orders
    FROM order_status 
    WHERE payment_status = 1 
    AND MONTH(order_date) = MONTH(CURDATE())
    AND YEAR(order_date) = YEAR(CURDATE())
")->fetch_assoc();

// Thống kê doanh thu theo tháng trong năm
$revenue_by_month = $conn->query("
    SELECT 
        MONTH(order_date) as month,
        YEAR(order_date) as year,
        SUM(total_amount) as total_revenue,
        COUNT(*) as order_count
    FROM order_status
    WHERE payment_status = 1
    GROUP BY YEAR(order_date), MONTH(order_date)
    ORDER BY year DESC, month DESC
    LIMIT 12
");

// Thống kê đơn hàng theo trạng thái
$order_stats = $conn->query("
    SELECT 
        payment_status,
        COUNT(*) as count
    FROM order_status
    GROUP BY payment_status
");

// Top 5 sản phẩm bán chạy
$top_products = $conn->query("
    SELECT 
        p.name,
        p.price,
        COUNT(o.product_id) as total_sold,
        p.price * COUNT(o.product_id) as total_revenue
    FROM products p
    LEFT JOIN orders o ON p.id = o.product_id
    GROUP BY p.id
    ORDER BY total_sold DESC
    LIMIT 5
");

// Thống kê người dùng mới
$new_users = $conn->query("
    SELECT COUNT(*) as count 
    FROM users 
    WHERE DATE(created_at) = CURDATE()
")->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thống kê</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4e73df;
            --primary-dark: #3a56c5;
            --secondary-color: #f8f9fc;
            --text-primary: #5a5c69;
            --text-secondary: #858796;
            --success: #1cc88a;
            --danger: #e74a3b;
            --warning: #f6c23e;
            --info: #36b9cc;
            --border-radius: 0.35rem;
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }
        
        body {
            background: #f8f9fc;
            color: var(--text-primary);
            min-height: 100vh;
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 20px 0;
            height: 100vh;
            position: fixed;
            transition: var(--transition);
            z-index: 100;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .sidebar h2 {
            font-size: 1.2rem;
            margin-bottom: 30px;
            padding: 0 20px;
            text-align: center;
            position: relative;
            padding-bottom: 15px;
        }
        
        .sidebar h2:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 60%;
            height: 1px;
            background: rgba(255,255,255,0.3);
        }
        
        .sidebar nav {
            display: flex;
            flex-direction: column;
        }
        
        .sidebar a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: var(--transition);
            border-left: 3px solid transparent;
        }
        
        .sidebar a:hover, .sidebar a.active {
            background-color: rgba(255,255,255,0.1);
            color: white;
            border-left-color: white;
        }
        
        .sidebar a i {
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            flex: 1;
            padding: 30px;
            margin-left: 260px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            border-bottom: 1px solid #e3e6f0;
            padding-bottom: 20px;
        }
        
        .header h1 {
            font-size: 1.75rem;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .back-button {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            border-radius: var(--border-radius);
            text-decoration: none;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .back-button:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }
        
        .revenue-overview {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: var(--border-radius);
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            position: relative;
            overflow: hidden;
            transition: var(--transition);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card h3 {
            color: var(--text-secondary);
            font-size: 0.9rem;
            text-transform: uppercase;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .stat-card .amount {
            font-size: 1.8rem;
            font-weight: bold;
            color: var(--text-primary);
        }
        
        .stat-card .order-count {
            font-size: 0.9rem;
            color: var(--text-secondary);
            margin-top: 5px;
        }
        
        .stat-card .icon {
            position: absolute;
            top: -10px;
            right: 10px;
            font-size: 4rem;
            opacity: 0.1;
            color: var(--primary-color);
        }
        
        .stat-card.daily {
            border-left: 4px solid var(--primary-color);
        }
        
        .stat-card.weekly {
            border-left: 4px solid var(--success);
        }
        
        .stat-card.monthly {
            border-left: 4px solid var(--warning);
        }
        
        .stat-card.daily .icon {
            color: var(--primary-color);
        }
        
        .stat-card.weekly .icon {
            color: var(--success);
        }
        
        .stat-card.monthly .icon {
            color: var(--warning);
        }
        
        .stat-card.daily .amount {
            color: var(--primary-color);
        }
        
        .stat-card.weekly .amount {
            color: var(--success);
        }
        
        .stat-card.monthly .amount {
            color: var(--warning);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .chart-container {
            background: white;
            padding: 25px;
            border-radius: var(--border-radius);
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
        }
        
        .chart-container h2 {
            color: var(--text-primary);
            font-size: 1.2rem;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e3e6f0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .revenue-chart {
            grid-column: 1 / -1;
            height: 400px;
        }
        
        .chart-wrapper {
            position: relative;
            height: 350px;
        }
        
        .order-status-chart {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .pie-chart-container {
            width: 300px;
            height: 300px;
            margin: 0 auto;
        }
        
        .top-products {
            padding: 25px;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
        }
        
        .top-products h2 {
            color: var(--text-primary);
            font-size: 1.2rem;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e3e6f0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .product-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .product-table th,
        .product-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e3e6f0;
        }
        
        .product-table th {
            background: var(--secondary-color);
            color: var(--text-primary);
            font-weight: 600;
        }
        
        .product-table tr:hover {
            background: rgba(0,0,0,0.02);
        }
        
        .product-table td:nth-child(2),
        .product-table td:nth-child(4) {
            text-align: right;
            font-weight: 600;
        }
        
        .product-table td:nth-child(3) {
            color: var(--text-secondary);
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            
            .sidebar h2 {
                display: none;
            }
            
            .sidebar a span {
                display: none;
            }
            
            .sidebar a {
                justify-content: center;
            }
            
            .sidebar a i {
                margin: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 20px;
            }
            
            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .back-button {
                width: 100%;
                text-align: center;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .revenue-overview {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
                <a href="admin_dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
                <a href="manage_products.php">
                    <i class="fas fa-hamburger"></i>
                    <span>Quản lý món ăn</span>
                </a>
                <a href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Quản lý người dùng</span>
                </a>
                <a href="manage_news.php">
                    <i class="fas fa-newspaper"></i>
                    <span>Quản lý tin tức</span>
                </a>
                <a href="statistics.php" class="active">
                    <i class="fas fa-chart-bar"></i>
                    <span>Thống kê</span>
                </a>
                <a href="admin_logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Đăng xuất</span>
                </a>
            </nav>
        </div>

        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-chart-line"></i> Thống kê doanh thu</h1>
                <a href="admin_dashboard.php" class="back-button">
                    <i class="fas fa-arrow-left"></i> Về Dashboard
                </a>
            </div>

            <div class="revenue-overview">
                <div class="stat-card daily">
                    <h3>Doanh thu hôm nay</h3>
                    <div class="amount"><?php echo number_format($daily_revenue['revenue'] ?? 0); ?> VNĐ</div>
                    <div class="order-count"><?php echo $daily_revenue['orders'] ?? 0; ?> đơn hàng</div>
                    <i class="fas fa-calendar-day icon"></i>
                </div>
                <div class="stat-card weekly">
                    <h3>Doanh thu tuần này</h3>
                    <div class="amount"><?php echo number_format($weekly_revenue['revenue'] ?? 0); ?> VNĐ</div>
                    <div class="order-count"><?php echo $weekly_revenue['orders'] ?? 0; ?> đơn hàng</div>
                    <i class="fas fa-calendar-week icon"></i>
                </div>
                <div class="stat-card monthly">
                    <h3>Doanh thu tháng này</h3>
                    <div class="amount"><?php echo number_format($monthly_revenue['revenue'] ?? 0); ?> VNĐ</div>
                    <div class="order-count"><?php echo $monthly_revenue['orders'] ?? 0; ?> đơn hàng</div>
                    <i class="fas fa-calendar-alt icon"></i>
                </div>
            </div>

            <div class="stats-grid">
                <div class="chart-container revenue-chart">
                    <h2><i class="fas fa-chart-area"></i> Doanh thu 12 tháng gần nhất</h2>
                    <div class="chart-wrapper">
                        <canvas id="revenueChart"></canvas>
                    </div>
                </div>

                <div class="chart-container order-status-chart">
                    <h2><i class="fas fa-chart-pie"></i> Trạng thái đơn hàng</h2>
                    <div class="pie-chart-container">
                        <canvas id="orderStatusChart"></canvas>
                    </div>
                </div>

                <div class="top-products">
                    <h2><i class="fas fa-trophy"></i> Top 5 sản phẩm bán chạy</h2>
                    <table class="product-table">
                        <thead>
                            <tr>
                                <th>Tên sản phẩm</th>
                                <th>Đã bán</th>
                                <th>Đơn giá</th>
                                <th>Doanh thu</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($product = $top_products->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($product['name']); ?></td>
                                <td><?php echo $product['total_sold']; ?> món</td>
                                <td><?php echo number_format($product['price']); ?> VNĐ</td>
                                <td><?php echo number_format($product['total_revenue']); ?> VNĐ</td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
    // Biểu đồ doanh thu
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    new Chart(revenueCtx, {
        type: 'line',
        data: {
            labels: [
                <?php
                $labels = [];
                $data = [];
                $orderCounts = [];
                while($row = $revenue_by_month->fetch_assoc()) {
                    $labels[] = "Tháng {$row['month']}/{$row['year']}";
                    $data[] = $row['total_revenue'];
                    $orderCounts[] = $row['order_count'];
                }
                echo "'" . implode("','", array_reverse($labels)) . "'";
                ?>
            ],
            datasets: [{
                label: 'Doanh thu (VNĐ)',
                data: [<?php echo implode(',', array_reverse($data)); ?>],
                borderColor: 'rgb(78, 115, 223)',
                backgroundColor: 'rgba(78, 115, 223, 0.1)',
                borderWidth: 3,
                tension: 0.4,
                fill: true,
                pointRadius: 5,
                pointBackgroundColor: 'rgb(78, 115, 223)',
                pointBorderColor: 'white',
                pointBorderWidth: 2,
                pointHoverRadius: 7,
                pointHoverBackgroundColor: 'white',
                pointHoverBorderColor: 'rgb(78, 115, 223)',
                pointHoverBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        font: {
                            size: 14,
                            weight: 'bold'
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleFont: {
                        size: 16,
                        weight: 'bold'
                    },
                    bodyFont: {
                        size: 14
                    },
                    padding: 15,
                    cornerRadius: 5,
                    displayColors: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        drawBorder: false
                    },
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString() + ' VNĐ';
                        },
                        font: {
                            size: 12
                        }
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        font: {
                            size: 12
                        }
                    }
                }
            }
        }
    });

    // Biểu đồ trạng thái đơn hàng
    const orderStatusCtx = document.getElementById('orderStatusChart').getContext('2d');
    new Chart(orderStatusCtx, {
        type: 'doughnut',
        data: {
            labels: ['Chờ thanh toán', 'Đã thanh toán'],
            datasets: [{
                data: [
                    <?php
                    $status_counts = array(0, 0);
                    while($status = $order_stats->fetch_assoc()) {
                        $status_counts[$status['payment_status']] = $status['count'];
                    }
                    echo implode(',', $status_counts);
                    ?>
                ],
                backgroundColor: [
                    'rgb(246, 194, 62)',
                    'rgb(28, 200, 138)'
                ],
                borderColor: 'white',
                borderWidth: 2,
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        font: {
                            size: 14
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleFont: {
                        size: 16,
                        weight: 'bold'
                    },
                    bodyFont: {
                        size: 14
                    },
                    padding: 15,
                    cornerRadius: 5,
                    displayColors: true
                }
            },
            cutout: '70%'
        }
    });
    </script>
</body>
</html>

<?php
$conn->close();
?>