<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Lấy thông tin người dùng
$sql = "SELECT username, email FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Lấy thông tin từ customer_info
$sql_customer = "SELECT full_name, phone, address FROM customer_info WHERE user_id = ?";
$stmt_customer = $conn->prepare($sql_customer);
$stmt_customer->bind_param("i", $user_id);
$stmt_customer->execute();
$result_customer = $stmt_customer->get_result();
$customer = $result_customer->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thông Tin Tài Khoản</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="account-container">
        <h2>Thông Tin Tài Khoản</h2>
        <div class="account-info">
            <h3>Thông tin đăng nhập</h3>
            <p><strong>Tên đăng nhập:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>

            <?php if ($customer): ?>
            <h3>Thông tin cá nhân</h3>
            <p><strong>Họ và tên:</strong> <?php echo htmlspecialchars($customer['full_name']); ?></p>
            <p><strong>Số điện thoại:</strong> <?php echo htmlspecialchars($customer['phone']); ?></p>
            <p><strong>Địa chỉ:</strong> <?php echo htmlspecialchars($customer['address']); ?></p>
            <?php endif; ?>
        </div>
        <a href="index.php" class="back-btn">Quay lại trang chủ</a>
    </div>
</body>
</html>