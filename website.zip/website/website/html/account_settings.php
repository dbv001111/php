<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$message = '';
$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Update user table
    $new_username = trim($_POST['username']);
    $new_email = trim($_POST['email']);
    $new_password = trim($_POST['new_password']);
    
    // Update customer_info table
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);

    $conn->begin_transaction();
    try {
        // Update users table
        if ($new_password !== '') {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $sql = "UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssi", $new_username, $new_email, $hashed_password, $user_id);
        } else {
            $sql = "UPDATE users SET username = ?, email = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssi", $new_username, $new_email, $user_id);
        }
        $stmt->execute();

        // Update or Insert customer_info
        $sql = "INSERT INTO customer_info (user_id, full_name, phone, address) 
                VALUES (?, ?, ?, ?) 
                ON DUPLICATE KEY UPDATE 
                full_name = VALUES(full_name), 
                phone = VALUES(phone), 
                address = VALUES(address)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isss", $user_id, $full_name, $phone, $address);
        $stmt->execute();

        $conn->commit();
        $message = "Cập nhật thông tin thành công!";
    } catch (Exception $e) {
        $conn->rollback();
        $message = "Có lỗi xảy ra: " . $e->getMessage();
    }
}

// Get current user info
$sql = "SELECT u.username, u.email, c.full_name, c.phone, c.address 
        FROM users u 
        LEFT JOIN customer_info c ON u.id = c.user_id 
        WHERE u.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Cài Đặt Tài Khoản</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="settings-container">
        <h2>Cài Đặt Tài Khoản</h2>
        <?php if ($message): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <form method="POST" class="settings-form">
            <h3>Thông tin đăng nhập</h3>
            <div class="form-group">
                <label for="username">Tên đăng nhập:</label>
                <input type="text" id="username" name="username" 
                       value="<?php echo htmlspecialchars($user['username']); ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" 
                       value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>

            <div class="form-group">
                <label for="new_password">Mật khẩu mới (để trống nếu không đổi):</label>
                <input type="password" id="new_password" name="new_password">
            </div>

            <h3>Thông tin cá nhân</h3>
            <div class="form-group">
                <label for="full_name">Họ và tên:</label>
                <input type="text" id="full_name" name="full_name" 
                       value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label for="phone">Số điện thoại:</label>
                <input type="tel" id="phone" name="phone" 
                       value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label for="address">Địa chỉ:</label>
                <textarea id="address" name="address" required><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
            </div>

            <button type="submit" class="submit-btn">Cập nhật</button>
        </form>
        <a href="index.php" class="back-btn">Quay lại trang chủ</a>
    </div>
</body>
</html>