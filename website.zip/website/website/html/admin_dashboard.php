<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "website");

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

$result_products = $conn->query("SELECT COUNT(*) AS total_products FROM products");
$total_products = $result_products->fetch_assoc()['total_products'];

$result_users = $conn->query("SELECT COUNT(*) AS total_users FROM users");
$total_users = $result_users->fetch_assoc()['total_users'];

$result_orders = $conn->query("SELECT COUNT(*) AS total_orders FROM order_status WHERE DATE(order_date) = CURDATE()");
$total_orders = $result_orders->fetch_assoc()['total_orders'];

// Lấy đơn hàng mới nhất
$recent_orders = $conn->query("SELECT os.order_id, os.total_amount, os.payment_status, os.order_date FROM order_status os ORDER BY os.order_date DESC LIMIT 5");

// Lấy sản phẩm mới nhất
$recent_products = $conn->query("SELECT id, name, price, image FROM products ORDER BY created_at DESC LIMIT 5");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --primary-dark: #3a56c5;
            --secondary-color: #f8f9fc;
            --text-primary: #5a5c69;
            --text-secondary: #858796;
            --success: #1cc88a;
            --danger: #e74a3b;
            --warning: #f6c23e;
            --border-radius: 0.35rem;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }
        
        body {
            background: #f8f9fc;
            color: var(--text-primary);
            min-height: 100vh;
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 20px 0;
            height: 100vh;
            position: fixed;
            transition: all 0.3s;
            z-index: 100;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .sidebar h2 {
            font-size: 1.2rem;
            margin-bottom: 30px;
            padding: 0 20px;
            text-align: center;
            position: relative;
            padding-bottom: 15px;
        }
        
        .sidebar h2:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 60%;
            height: 1px;
            background: rgba(255,255,255,0.3);
        }
        
        .sidebar nav {
            display: flex;
            flex-direction: column;
        }
        
        .sidebar a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        
        .sidebar a:hover, .sidebar a.active {
            background-color: rgba(255,255,255,0.1);
            color: white;
            border-left-color: white;
        }
        
        .sidebar a i {
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            flex: 1;
            padding: 30px;
            margin-left: 260px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            border-bottom: 1px solid #e3e6f0;
            padding-bottom: 20px;
        }
        
        .page-header h1 {
            font-size: 1.75rem;
            color: var(--text-primary);
        }
        
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .card {
            background: white;
            padding: 25px;
            border-radius: var(--border-radius);
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            position: relative;
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-5px);
        }
        
        .card h3 {
            font-size: 0.9rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--text-secondary);
            margin-bottom: 15px;
        }
        
        .card p {
            font-size: 1.8rem;
            font-weight: bold;
            margin-bottom: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .color-products { color: var(--primary-color); }
        .color-users { color: var(--success); }
        .color-orders { color: var(--warning); }
        
        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
        }
        
        .card.products::before { background-color: var(--primary-color); }
        .card.users::before { background-color: var(--success); }
        .card.orders::before { background-color: var(--warning); }
        
        .card-icon {
            position: absolute;
            top: 10px;
            right: 20px;
            font-size: 2.5rem;
            opacity: 0.2;
        }
        
        .recent-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
        }
        
        .recent-section {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            overflow: hidden;
        }
        
        .recent-header {
            background: var(--primary-color);
            color: white;
            padding: 15px 20px;
        }
        
        .recent-header h3 {
            font-size: 1rem;
            margin: 0;
        }
        
        .recent-body {
            padding: 20px;
        }
        
        .recent-list {
            list-style: none;
        }
        
        .recent-item {
            padding: 15px 0;
            border-bottom: 1px solid #edf0f5;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .recent-item:last-child {
            border-bottom: none;
        }
        
        .product-img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 5px;
        }
        
        .recent-info {
            flex: 1;
        }
        
        .recent-info h4 {
            font-size: 0.9rem;
            color: var(--text-primary);
            margin-bottom: 5px;
        }
        
        .recent-info p {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin: 0;
        }
        
        .status-badge {
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: bold;
        }
        
        .status-paid {
            background-color: rgba(28, 200, 138, 0.1);
            color: var(--success);
        }
        
        .status-pending {
            background-color: rgba(246, 194, 62, 0.1);
            color: var(--warning);
        }
        
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            
            .sidebar h2 {
                display: none;
            }
            
            .sidebar a span {
                display: none;
            }
            
            .sidebar a {
                justify-content: center;
            }
            
            .sidebar a i {
                margin: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
        
        @media (max-width: 576px) {
            .dashboard-cards {
                grid-template-columns: 1fr;
            }
            
            .recent-content {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
                <a href="admin_dashboard.php" class="active">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
                <a href="manage_products.php">
                    <i class="fas fa-hamburger"></i>
                    <span>Quản lý món ăn</span>
                </a>
                <a href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Quản lý người dùng</span>
                </a>
                <a href="manage_news.php">
                    <i class="fas fa-newspaper"></i>
                    <span>Quản lý tin tức</span>
                </a>
                <a href="statistics.php">
                    <i class="fas fa-chart-bar"></i>
                    <span>Thống kê</span>
                </a>
                <a href="admin_logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Đăng xuất</span>
                </a>
            </nav>
        </div>
        
        <div class="main-content">
            <div class="page-header">
                <h1>Dashboard</h1>
                <div class="date">
                    <i class="fas fa-calendar"></i>
                    <?php echo date('d/m/Y'); ?>
                </div>
            </div>
            
            <div class="dashboard-cards">
                <div class="card products">
                    <h3>Tổng số món ăn</h3>
                    <p class="color-products"><?php echo $total_products; ?></p>
                    <i class="fas fa-utensils card-icon"></i>
                </div>
                <div class="card users">
                    <h3>Tổng số người dùng</h3>
                    <p class="color-users"><?php echo $total_users; ?></p>
                    <i class="fas fa-user card-icon"></i>
                </div>
                <div class="card orders">
                    <h3>Đơn hàng hôm nay</h3>
                    <p class="color-orders"><?php echo $total_orders; ?></p>
                    <i class="fas fa-shopping-cart card-icon"></i>
                </div>
            </div>
            
            <div class="recent-content">
                <div class="recent-section">
                    <div class="recent-header">
                        <h3>Đơn hàng gần đây</h3>
                    </div>
                    <div class="recent-body">
                        <ul class="recent-list">
                            <?php if ($recent_orders->num_rows > 0): ?>
                                <?php while ($order = $recent_orders->fetch_assoc()): ?>
                                    <li class="recent-item">
                                        <div class="recent-info">
                                            <h4>Đơn #<?php echo substr($order['order_id'], -5); ?></h4>
                                            <p><?php echo number_format($order['total_amount']); ?> VNĐ</p>
                                            <p><?php echo date('d/m/Y H:i', strtotime($order['order_date'])); ?></p>
                                        </div>
                                        <span class="status-badge <?php echo $order['payment_status'] ? 'status-paid' : 'status-pending'; ?>">
                                            <?php echo $order['payment_status'] ? 'Đã thanh toán' : 'Chờ thanh toán'; ?>
                                        </span>
                                    </li>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <li class="recent-item">Không có đơn hàng nào</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                
                <div class="recent-section">
                    <div class="recent-header">
                        <h3>Sản phẩm mới nhất</h3>
                    </div>
                    <div class="recent-body">
                        <ul class="recent-list">
                            <?php if ($recent_products->num_rows > 0): ?>
                                <?php while ($product = $recent_products->fetch_assoc()): ?>
                                    <li class="recent-item">
                                        <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-img">
                                        <div class="recent-info">
                                            <h4><?php echo htmlspecialchars($product['name']); ?></h4>
                                            <p><?php echo number_format($product['price']); ?> VNĐ</p>
                                        </div>
                                    </li>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <li class="recent-item">Không có sản phẩm nào</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php
$conn->close();
?>