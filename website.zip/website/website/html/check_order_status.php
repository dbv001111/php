<?php
session_start();
header('Content-Type: application/json');

$conn = new mysqli("localhost", "root", "", "website");

if ($conn->connect_error) {
    die(json_encode([
        "status" => "error",
        "message" => "Kết nối thất bại: " . $conn->connect_error
    ]));
}

$order_id = $_SESSION['last_order_id'] ?? null;

if (!$order_id) {
    echo json_encode([
        "status" => "error",
        "message" => "Không tìm thấy đơn hàng!"
    ]);
    exit();
}

$stmt = $conn->prepare("SELECT order_id, payment_method, total_amount, shipping_address, payment_status, order_date 
                       FROM order_status WHERE order_id = ?");
$stmt->bind_param("s", $order_id);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $status_text = ($row['payment_status'] == 1) ? "Đã thanh toán" : "Chờ thanh toán";
    
    echo json_encode([
        "status" => "success",
        "order_id" => $row['order_id'],
        "payment_method" => $row['payment_method'],
        "total_amount" => number_format($row['total_amount']) . " VNĐ",
        "shipping_address" => $row['shipping_address'],
        "payment_status" => $status_text,
        "order_date" => date('d/m/Y H:i', strtotime($row['order_date']))
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Không tìm thấy thông tin đơn hàng!"
    ]);
}

$stmt->close();
$conn->close();
?>