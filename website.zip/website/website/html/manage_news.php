<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "website");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_news'])) {
        $title = $conn->real_escape_string($_POST['title']);
        $content = $conn->real_escape_string($_POST['content']);
        
        $target_dir = "uploads/news/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $image_path = '';
        if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
            $target_file = $target_dir . time() . '_' . basename($_FILES["image"]["name"]);
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                $image_path = $target_file;
            }
        }

        $sql = "INSERT INTO news (title, content, image, created_at) VALUES (?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $title, $content, $image_path);
        
        if ($stmt->execute()) {
            $success_message = "Thêm tin tức thành công!";
        } else {
            $error_message = "Lỗi: " . $stmt->error;
        }
    }

    if (isset($_POST['delete_news'])) {
        $news_id = intval($_POST['news_id']);
        
        // Get image path before deleting
        $result = $conn->query("SELECT image FROM news WHERE id = $news_id");
        if ($row = $result->fetch_assoc()) {
            $image_path = $row['image'];
            
            // Delete the image file if it exists
            if (!empty($image_path) && file_exists($image_path)) {
                unlink($image_path);
            }
        }
        
        if ($conn->query("DELETE FROM news WHERE id = $news_id")) {
            $success_message = "Xóa tin tức thành công!";
        } else {
            $error_message = "Lỗi: " . $conn->error;
        }
    }
}

$result = $conn->query("SELECT * FROM news ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý tin tức</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4e73df;
            --primary-dark: #3a56c5;
            --secondary-color: #f8f9fc;
            --text-primary: #5a5c69;
            --text-secondary: #858796;
            --success: #1cc88a;
            --danger: #e74a3b;
            --warning: #f6c23e;
            --info: #36b9cc;
            --border-radius: 0.35rem;
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }
        
        body {
            background: #f8f9fc;
            color: var(--text-primary);
            min-height: 100vh;
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 20px 0;
            height: 100vh;
            position: fixed;
            transition: var(--transition);
            z-index: 100;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .sidebar h2 {
            font-size: 1.2rem;
            margin-bottom: 30px;
            padding: 0 20px;
            text-align: center;
            position: relative;
            padding-bottom: 15px;
        }
        
        .sidebar h2:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 60%;
            height: 1px;
            background: rgba(255,255,255,0.3);
        }
        
        .sidebar nav {
            display: flex;
            flex-direction: column;
        }
        
        .sidebar a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: var(--transition);
            border-left: 3px solid transparent;
        }
        
        .sidebar a:hover, .sidebar a.active {
            background-color: rgba(255,255,255,0.1);
            color: white;
            border-left-color: white;
        }
        
        .sidebar a i {
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            flex: 1;
            padding: 30px;
            margin-left: 260px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            border-bottom: 1px solid #e3e6f0;
            padding-bottom: 20px;
        }
        
        .header h1 {
            font-size: 1.75rem;
            color: var(--text-primary);
        }
        
        .back-btn {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            border-radius: var(--border-radius);
            text-decoration: none;
            transition: var(--transition);
        }
        
        .back-btn:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }
        
        .section {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            padding: 25px;
            margin-bottom: 30px;
        }
        
        .section h2 {
            color: var(--text-primary);
            font-size: 1.3rem;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e3e6f0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .form-group input[type="text"],
        .form-group textarea,
        .form-group input[type="file"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #d1d3e2;
            border-radius: var(--border-radius);
            transition: var(--transition);
        }
        
        .form-group input[type="text"]:focus,
        .form-group textarea:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
            outline: none;
        }
        
        .form-group textarea {
            min-height: 150px;
            resize: vertical;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: var(--primary-color);
            color: white;
        }
        
        .btn-danger {
            background: var(--danger);
            color: white;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 0.125rem 0.25rem 0 rgba(58, 59, 69, 0.2);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e3e6f0;
        }
        
        th {
            background: var(--secondary-color);
            color: var(--text-primary);
            font-weight: 600;
        }
        
        tr:hover {
            background: rgba(0,0,0,0.02);
        }
        
        .preview-content {
            max-height: 100px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            color: var(--text-secondary);
        }
        
        .product-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 5px;
            transition: transform 0.3s ease;
            cursor: pointer;
        }
        
        .product-image:hover {
            transform: scale(1.1);
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: var(--border-radius);
        }
        
        .alert-success {
            background-color: rgba(28, 200, 138, 0.1);
            border-color: rgba(28, 200, 138, 0.2);
            color: var(--success);
        }
        
        .alert-danger {
            background-color: rgba(231, 74, 59, 0.1);
            border-color: rgba(231, 74, 59, 0.2);
            color: var(--danger);
        }
        
        .image-preview {
            margin-top: 15px;
            max-width: 300px;
            border-radius: var(--border-radius);
            box-shadow: 0 0.125rem 0.25rem 0 rgba(58, 59, 69, 0.2);
            display: none;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 30px;
            width: 80%;
            max-width: 800px;
            border-radius: var(--border-radius);
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.15);
            animation: modalFadeIn 0.3s ease;
        }
        
        @keyframes modalFadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .close {
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            color: var(--text-secondary);
            transition: color 0.3s ease;
        }
        
        .close:hover {
            color: var(--text-primary);
        }
        
        .modal-body {
            margin-top: 20px;
        }
        
        .modal-img {
            max-width: 100%;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            
            .sidebar h2 {
                display: none;
            }
            
            .sidebar a span {
                display: none;
            }
            
            .sidebar a {
                justify-content: center;
            }
            
            .sidebar a i {
                margin: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 20px;
            }
            
            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .back-btn {
                width: 100%;
                text-align: center;
            }
            
            th, td {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
                <a href="admin_dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
                <a href="manage_products.php">
                    <i class="fas fa-hamburger"></i>
                    <span>Quản lý món ăn</span>
                </a>
                <a href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Quản lý người dùng</span>
                </a>
                <a href="manage_news.php" class="active">
                    <i class="fas fa-newspaper"></i>
                    <span>Quản lý tin tức</span>
                </a>
                <a href="statistics.php">
                    <i class="fas fa-chart-bar"></i>
                    <span>Thống kê</span>
                </a>
                <a href="admin_logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Đăng xuất</span>
                </a>
            </nav>
        </div>

        <div class="main-content">
            <div class="header">
                <h1>Quản lý tin tức</h1>
                <a href="admin_dashboard.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i> Về Dashboard
                </a>
            </div>
            
            <?php if (isset($success_message)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
            </div>
            <?php endif; ?>
            
            <?php if (isset($error_message)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
            </div>
            <?php endif; ?>

            <div class="section">
                <h2><i class="fas fa-plus-circle"></i> Thêm tin tức mới</h2>
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Tiêu đề:</label>
                        <input type="text" name="title" required placeholder="Nhập tiêu đề tin tức">
                    </div>
                    <div class="form-group">
                        <label>Nội dung:</label>
                        <textarea name="content" required rows="5" placeholder="Nhập nội dung tin tức"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Hình ảnh:</label>
                        <input type="file" name="image" accept="image/*" id="news-image">
                        <img id="image-preview" class="image-preview">
                    </div>
                    <button type="submit" name="add_news" class="btn btn-primary">
                        <i class="fas fa-save"></i> Thêm tin tức
                    </button>
                </form>
            </div>

            <div class="section">
                <h2><i class="fas fa-list"></i> Danh sách tin tức</h2>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Hình ảnh</th>
                                <th>Tiêu đề</th>
                                <th>Nội dung</th>
                                <th>Ngày đăng</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result->num_rows > 0): ?>
                                <?php while ($row = $result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $row['id']; ?></td>
                                        <td>
                                            <?php if ($row['image']): ?>
                                                <img src="<?php echo $row['image']; ?>" alt="News Image" class="product-image" onclick="showImageModal('<?php echo $row['image']; ?>', '<?php echo htmlspecialchars($row['title']); ?>')">
                                            <?php else: ?>
                                                <i class="fas fa-image" style="color: #ccc; font-size: 40px;"></i>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                                        <td>
                                            <div class="preview-content">
                                                <?php echo htmlspecialchars($row['content']); ?>
                                            </div>
                                        </td>
                                        <td><?php echo date('d/m/Y H:i', strtotime($row['created_at'])); ?></td>
                                        <td>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="news_id" value="<?php echo $row['id']; ?>">
                                                <button type="submit" name="delete_news" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa tin tức này?')">
                                                    <i class="fas fa-trash-alt"></i> Xóa
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" style="text-align: center;">Không có tin tức nào.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal hiển thị ảnh -->
    <div id="imageModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2 id="modal-title"></h2>
            <div class="modal-body">
                <img id="modal-img" class="modal-img">
            </div>
        </div>
    </div>

    <script>
    // Hiển thị hình ảnh khi upload
    document.getElementById('news-image').addEventListener('change', function(e) {
        const preview = document.getElementById('image-preview');
        const file = e.target.files[0];
        
        if (file) {
            const reader = new FileReader();
            
            reader.onload = function(event) {
                preview.src = event.target.result;
                preview.style.display = 'block';
            }
            
            reader.readAsDataURL(file);
        } else {
            preview.style.display = 'none';
        }
    });
    
    // Modal hiển thị ảnh
    function showImageModal(imageSrc, title) {
        const modal = document.getElementById('imageModal');
        const modalImg = document.getElementById('modal-img');
        const modalTitle = document.getElementById('modal-title');
        
        modalImg.src = imageSrc;
        modalTitle.textContent = title;
        modal.style.display = 'block';
    }
    
    function closeModal() {
        document.getElementById('imageModal').style.display = 'none';
    }
    
    // Đóng modal khi click bên ngoài
    window.onclick = function(event) {
        const modal = document.getElementById('imageModal');
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    }
    
    // Auto-hide alerts after 5 seconds
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            
            alerts.forEach(function(alert) {
                alert.style.opacity = '0';
                setTimeout(function() {
                    alert.style.display = 'none';
                }, 500);
            });
        }, 5000);
    });
    </script>
</body>
</html>

<?php
$conn->close();
?>