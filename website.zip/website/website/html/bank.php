<?php
session_start();

// Kiểm tra đăng nhập và giỏ hàng
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo '<p>Giỏ hàng của bạn đang trống.</p>';
    exit();
}

$total_amount = isset($_SESSION['total_amount']) ? $_SESSION['total_amount'] : 0;
$bank_account = '1048238244'; // Số tài khoản cố định của cửa hàng

try {
    $pdo = new PDO("mysql:host=localhost;dbname=website", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Kiểm tra dữ liệu đầu vào
        if (empty($_POST['shipping_address'])) {
            die("Lỗi: Địa chỉ giao hàng không được để trống");
        }

        $order_id = 'ORD' . time();
        $shipping_address = $_POST['shipping_address'];
        $user_id = (int)$_SESSION['user_id'];

        $pdo->beginTransaction();

        try {
            foreach($_SESSION['cart'] as $product_id) {
                if (isset($_SESSION['quantity'][$product_id])) {
                    $quantity = (int)$_SESSION['quantity'][$product_id];
                    $product_id = (int)$product_id;

                    // Thêm vào bảng orders
                    $stmt = $pdo->prepare("INSERT INTO orders (user_id, product_id, quantity) VALUES (?, ?, ?)");
                    $stmt->execute([$user_id, $product_id, $quantity]);
                    $order_reference_id = $pdo->lastInsertId();

                    // Thêm vào bảng order_status
                    $payment_method = 'Ngân hàng';
                    $stmt = $pdo->prepare("INSERT INTO order_status (order_id, order_reference_id, payment_method, total_amount, shipping_address, payment_status) VALUES (?, ?, ?, ?, ?, 0)");
                    $stmt->execute([$order_id, $order_reference_id, $payment_method, $total_amount, $shipping_address]);
                }
            }

            $pdo->commit();

            // Lưu order_id cho trang sau và xóa giỏ hàng
            $_SESSION['last_order_id'] = $order_id;
            $_SESSION['cart'] = array();
            $_SESSION['quantity'] = array();
            $_SESSION['payment_success'] = true;
            
            // Redirect to success page instead of showing alert
            header("Location: payment_success.php?method=bank");
            exit();

        } catch (Exception $e) {
            $pdo->rollBack();
            die("Lỗi khi xử lý đơn hàng: " . $e->getMessage());
        }
    }
} catch(PDOException $e) {
    die("Kết nối thất bại: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanh Toán Qua Ngân Hàng</title>
    <link rel="stylesheet" href="css/bank.css">
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="path_to_your_logo.png" alt="Logo">
        </div>
        <h1>Thanh Toán Qua Ngân Hàng</h1>
        
        <form method="POST" action="" id="paymentForm">
            <div class="input-field">
                <label for="shipping_address">Địa chỉ giao hàng</label>
                <input type="text" id="shipping_address" name="shipping_address" required 
                       placeholder="Nhập địa chỉ giao hàng của bạn">
            </div>

            <div class="qr-section">
                <img src="uploads/qr.jpg" alt="Mã QR" class="qr-code">
                <div class="account-info">
                    <div class="account-bank">VIETCOMBANK</div>
                    <div class="account-name">DINH BA VU</div>
                    <div class="account-number">
                        <span>STK:</span> <?php echo $bank_account; ?>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn">Xác nhận thanh toán</button>
            <a href="giohang.php" class="btn back-btn">Trở về Giỏ hàng</a>
        </form>

        <div class="total-amount">
            Tổng số tiền: <?php echo number_format($total_amount); ?> VNĐ
        </div>
    </div>

    <script>
    document.getElementById('paymentForm').onsubmit = function(e) {
        const address = document.getElementById('shipping_address').value.trim();
        if (!address) {
            e.preventDefault();
            alert('Vui lòng nhập địa chỉ giao hàng');
            return false;
        }
        return true;
    };
    </script>
</body>
</html>