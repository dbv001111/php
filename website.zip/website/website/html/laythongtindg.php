<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Không có quyền truy cập'
    ]);
    exit();
}

require_once 'db_connect.php';
header('Content-Type: application/json');

if (!isset($_GET['product_id'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Thiếu thông tin sản phẩm'
    ]);
    exit();
}

$product_id = intval($_GET['product_id']);

try {
    // Lấy thông tin sản phẩm
    $product_stmt = $conn->prepare("SELECT name FROM products WHERE id = ?");
    $product_stmt->bind_param("i", $product_id);
    $product_stmt->execute();
    $product_result = $product_stmt->get_result();
    $product = $product_result->fetch_assoc();

    if (!$product) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Không tìm thấy sản phẩm'
        ]);
        exit();
    }

    // Lấy danh sách đánh giá
    $reviews_stmt = $conn->prepare("
        SELECT r.*, u.username
        FROM reviews r
        JOIN users u ON r.user_id = u.id
        WHERE r.product_id = ?
        ORDER BY r.created_at DESC
    ");
    $reviews_stmt->bind_param("i", $product_id);
    $reviews_stmt->execute();
    $reviews_result = $reviews_stmt->get_result();
    
    $reviews = [];
    while ($review = $reviews_result->fetch_assoc()) {
        // Format lại dữ liệu
        $reviews[] = [
            'id' => $review['id'],
            'username' => htmlspecialchars($review['username']),
            'rating' => $review['rating'],
            'comment' => htmlspecialchars($review['comment']),
            'created_at' => date('d/m/Y H:i', strtotime($review['created_at']))
        ];
    }

    echo json_encode([
        'status' => 'success',
        'product_name' => htmlspecialchars($product['name']),
        'reviews' => $reviews
    ]);

} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Lỗi: ' . $e->getMessage()
    ]);
}
?>