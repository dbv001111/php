<?php
session_start();
require_once 'db_connect.php';
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Bạn cần đăng nhập để hủy đơn hàng!'
    ]);
    exit();
}

// Check if order ID is provided
if (!isset($_POST['order_id'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Thiếu thông tin đơn hàng!'
    ]);
    exit();
}

$order_id = $_POST['order_id'];
$user_id = $_SESSION['user_id'];

// Verify order belongs to this user and is cancellable
$check_stmt = $conn->prepare("
    SELECT os.* FROM order_status os
    JOIN orders o ON os.order_reference_id = o.id
    WHERE os.order_id = ? AND o.user_id = ? AND os.payment_status = 0 AND os.status != 'cancelled'
");

$check_stmt->bind_param("si", $order_id, $user_id);
$check_stmt->execute();
$result = $check_stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Đơn hàng không tồn tại hoặc không thể hủy!'
    ]);
    exit();
}

// Cancel the order
$update_stmt = $conn->prepare("UPDATE order_status SET status = 'cancelled' WHERE order_id = ?");
$update_stmt->bind_param("s", $order_id);

if ($update_stmt->execute()) {
    echo json_encode([
        'status' => 'success',
        'message' => 'Đơn hàng #' . $order_id . ' đã được hủy thành công!'
    ]);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Có lỗi xảy ra khi hủy đơn hàng: ' . $conn->error
    ]);
}
?>