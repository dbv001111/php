<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "website");

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Handle product deletion
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $result = $conn->query("SELECT image FROM products WHERE id = $id");
    if ($row = $result->fetch_assoc()) {
        $image_path = $row['image'];
        if (file_exists($image_path)) {
            unlink($image_path);
        }
    }
    $conn->query("DELETE FROM products WHERE id = $id");
    header("Location: manage_products.php");
    exit();
}

// Handle order approval
if (isset($_POST['approve_order'])) {
    $order_id = $_POST['order_id'];
    $conn->query("UPDATE order_status SET payment_status = 1 WHERE order_id = '$order_id'");
    header("Location: manage_products.php");
    exit();
}

// Handle product addition
if (isset($_POST['add_product'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $price = floatval($_POST['price']);
    $description = $conn->real_escape_string($_POST['description']);
    $category_id = intval($_POST['category_id']);

    $target_dir = "uploads/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $target_file = $target_dir . time() . '_' . basename($_FILES["image"]["name"]);
    
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        $sql = "INSERT INTO products (name, price, image, description, category_id) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sdssi", $name, $price, $target_file, $description, $category_id);
        
        if ($stmt->execute()) {
            header("Location: manage_products.php");
            exit();
        }
    }
}

// Fetch necessary data
$orders = $conn->query("SELECT * FROM order_status ORDER BY order_date DESC");
$products = $conn->query("
    SELECT p.*, 
           COALESCE(AVG(r.rating), 0) as avg_rating,
           COUNT(r.id) as review_count
    FROM products p
    LEFT JOIN reviews r ON p.id = r.product_id
    GROUP BY p.id
");
$categories = $conn->query("SELECT * FROM categories");
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý món ăn và đơn hàng</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4e73df;
            --primary-dark: #3a56c5;
            --secondary-color: #f8f9fc;
            --text-primary: #5a5c69;
            --text-secondary: #858796;
            --success: #1cc88a;
            --danger: #e74a3b;
            --warning: #f6c23e;
            --border-radius: 0.35rem;
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Nunito', sans-serif;
        }
        
        body {
            background: #f8f9fc;
            color: var(--text-primary);
            min-height: 100vh;
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 20px 0;
            height: 100vh;
            position: fixed;
            transition: var(--transition);
            z-index: 100;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .sidebar h2 {
            font-size: 1.2rem;
            margin-bottom: 30px;
            padding: 0 20px;
            text-align: center;
            position: relative;
            padding-bottom: 15px;
        }
        
        .sidebar h2:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 60%;
            height: 1px;
            background: rgba(255,255,255,0.3);
        }
        
        .sidebar nav {
            display: flex;
            flex-direction: column;
        }
        
        .sidebar a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: var(--transition);
            border-left: 3px solid transparent;
        }
        
        .sidebar a:hover, .sidebar a.active {
            background-color: rgba(255,255,255,0.1);
            color: white;
            border-left-color: white;
        }
        
        .sidebar a i {
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            flex: 1;
            padding: 30px;
            margin-left: 260px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            border-bottom: 1px solid #e3e6f0;
            padding-bottom: 20px;
        }
        
        .header h1 {
            font-size: 1.75rem;
            color: var(--text-primary);
        }
        
        .back-btn {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            border-radius: var(--border-radius);
            text-decoration: none;
            transition: var(--transition);
        }
        
        .back-btn:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }
        
        .section {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            padding: 25px;
            margin-bottom: 30px;
        }
        
        .section h2 {
            color: var(--text-primary);
            font-size: 1.3rem;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e3e6f0;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #d1d3e2;
            border-radius: var(--border-radius);
            transition: var(--transition);
        }
        
        .form-group input[type="text"]:focus,
        .form-group input[type="number"]:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
            outline: none;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
        }
        
        .btn-primary {
            background: var(--primary-color);
            color: white;
        }
        
        .btn-danger {
            background: var(--danger);
            color: white;
        }
        
        .btn-success {
            background: var(--success);
            color: white;
        }
        
        .btn-info {
            background: #36b9cc;
            color: white;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 0.125rem 0.25rem 0 rgba(58, 59, 69, 0.2);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e3e6f0;
        }
        
        th {
            background: var(--secondary-color);
            color: var(--text-primary);
            font-weight: 600;
        }
        
        tr:hover {
            background: rgba(0,0,0,0.02);
        }
        
        .product-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 5px;
            transition: transform 0.3s ease;
        }
        
        .product-image:hover {
            transform: scale(1.1);
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        
        .status-pending {
            background: rgba(246, 194, 62, 0.1);
            color: var(--warning);
        }
        
        .status-completed {
            background: rgba(28, 200, 138, 0.1);
            color: var(--success);
        }
        
        .rating-stars {
            color: #f6c23e;
            display: inline-flex;
            margin-right: 10px;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 30px;
            width: 80%;
            max-width: 800px;
            border-radius: var(--border-radius);
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.15);
            animation: modalFadeIn 0.3s ease;
        }
        
        @keyframes modalFadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .close {
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            color: var(--text-secondary);
            transition: color 0.3s ease;
        }
        
        .close:hover {
            color: var(--text-primary);
        }
        
        .review-list {
            max-height: 400px;
            overflow-y: auto;
            margin-top: 20px;
            border: 1px solid #e3e6f0;
            border-radius: var(--border-radius);
        }
        
        .review-item {
            padding: 15px;
            border-bottom: 1px solid #e3e6f0;
        }
        
        .review-item:last-child {
            border-bottom: none;
        }
        
        .review-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .review-user {
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .review-date {
            color: var(--text-secondary);
            font-size: 0.9em;
        }
        
        .review-comment {
            margin-top: 10px;
            padding: 10px;
            background: var(--secondary-color);
            border-radius: var(--border-radius);
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            
            .sidebar h2 {
                display: none;
            }
            
            .sidebar a span {
                display: none;
            }
            
            .sidebar a {
                justify-content: center;
            }
            
            .sidebar a i {
                margin: 0;
                font-size: 1.2rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 20px;
            }
            
            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .back-btn {
                width: 100%;
                text-align: center;
            }
            
            th, td {
                padding: 10px;
            }
            
            .product-image {
                width: 60px;
                height: 60px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
                <a href="admin_dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
                <a href="manage_products.php" class="active">
                    <i class="fas fa-hamburger"></i>
                    <span>Quản lý món ăn</span>
                </a>
                <a href="manage_users.php">
                    <i class="fas fa-users"></i>
                    <span>Quản lý người dùng</span>
                </a>
                <a href="manage_news.php">
                    <i class="fas fa-newspaper"></i>
                    <span>Quản lý tin tức</span>
                </a>
                <a href="statistics.php">
                    <i class="fas fa-chart-bar"></i>
                    <span>Thống kê</span>
                </a>
                <a href="admin_logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Đăng xuất</span>
                </a>
            </nav>
        </div>

        <div class="main-content">
            <div class="header">
                <h1>Quản lý món ăn và đơn hàng</h1>
                <a href="admin_dashboard.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i> Về Dashboard
                </a>
            </div>

            <div class="section">
                <h2><i class="fas fa-plus-circle"></i> Thêm món ăn mới</h2>
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Tên món:</label>
                        <input type="text" name="name" required placeholder="Nhập tên món ăn">
                    </div>
                    <div class="form-group">
                        <label>Giá:</label>
                        <input type="number" name="price" step="1000" required placeholder="Nhập giá">
                    </div>
                    <div class="form-group">
                        <label>Danh mục:</label>
                        <select name="category_id" required>
                            <option value="">-- Chọn danh mục --</option>
                            <?php while ($category = $categories->fetch_assoc()): ?>
                                <option value="<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Hình ảnh:</label>
                        <input type="file" name="image" required accept="image/*">
                    </div>
                    <div class="form-group">
                        <label>Mô tả:</label>
                        <textarea name="description" rows="4" placeholder="Nhập mô tả món ăn"></textarea>
                    </div>
                    <button type="submit" name="add_product" class="btn btn-primary">
                        <i class="fas fa-save"></i> Thêm món ăn
                    </button>
                </form>
            </div>

            <div class="section">
                <h2><i class="fas fa-utensils"></i> Danh sách món ăn</h2>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Hình ảnh</th>
                                <th>Tên</th>
                                <th>Giá</th>
                                <th>Đánh giá</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $products->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['id']) ?></td>
                                    <td><img src="<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['name']) ?>" class="product-image"></td>
                                    <td><?= htmlspecialchars($row['name']) ?></td>
                                    <td><?= number_format($row['price']) ?>₫</td>
                                    <td>
                                        <div class="rating-stars">
                                            <?php
                                            $rating = round($row['avg_rating']);
                                            for ($i = 1; $i <= 5; $i++) {
                                                echo '<i class="' . ($i <= $rating ? 'fas' : 'far') . ' fa-star"></i>';
                                            }
                                            ?>
                                        </div>
                                        <?= number_format($row['avg_rating'], 1) ?>/5
                                        (<?= $row['review_count'] ?> đánh giá)
                                        <?php if ($row['review_count'] > 0): ?>
                                            <button class="btn btn-info btn-sm" onclick="showReviews(<?= $row['id'] ?>)">
                                                <i class="far fa-eye"></i> Xem
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="?delete=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa món ăn này?')">
                                            <i class="fas fa-trash"></i> Xóa
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="section">
                <h2><i class="fas fa-shopping-cart"></i> Quản lý đơn hàng</h2>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>Mã đơn</th>
                                <th>Phương thức</th>
                                <th>Tổng tiền</th>
                                <th>Địa chỉ</th>
                                <th>Ngày đặt</th>
                                <th>Trạng thái</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($order = $orders->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($order['order_id']) ?></td>
                                    <td><?= htmlspecialchars($order['payment_method']) ?></td>
                                    <td><?= number_format($order['total_amount']) ?> VNĐ</td>
                                    <td><?= htmlspecialchars($order['shipping_address']) ?></td>
                                    <td><?= date('d/m/Y H:i', strtotime($order['order_date'])) ?></td>
                                    <td>
                                        <span class="status-badge <?= $order['payment_status'] ? 'status-completed' : 'status-pending' ?>">
                                            <?= $order['payment_status'] ? 'Đã thanh toán' : 'Chờ thanh toán' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if (!$order['payment_status']): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">
                                                <button type="submit" name="approve_order" class="btn btn-success btn-sm">
                                                    <i class="fas fa-check-circle"></i> Duyệt
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Đánh giá -->
    <div id="reviewsModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeReviewsModal()">&times;</span>
            <h2 id="reviewsModalTitle">Đánh giá sản phẩm</h2>
            <div id="reviewsList" class="review-list">
                <!-- Danh sách đánh giá sẽ được thêm vào đây -->
            </div>
        </div>
    </div>

    <script>
    function showReviews(productId) {
        const modal = document.getElementById('reviewsModal');
        const reviewsList = document.getElementById('reviewsList');
        reviewsList.innerHTML = '<p style="text-align: center; padding: 20px;"><i class="fas fa-spinner fa-spin"></i> Đang tải đánh giá...</p>';
        modal.style.display = 'block';

        fetch(`laythongtindg.php?product_id=${productId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    document.getElementById('reviewsModalTitle').textContent = 
                        `Đánh giá cho: ${data.product_name}`;
                    
                    if (data.reviews.length > 0) {
                        let reviewsHtml = '';
                        data.reviews.forEach(review => {
                            const stars = '★'.repeat(review.rating) + '☆'.repeat(5 - review.rating);
                            reviewsHtml += `
                                <div class="review-item">
                                    <div class="review-header">
                                        <span class="review-user"><i class="fas fa-user-circle"></i> ${review.username}</span>
                                        <span class="review-date"><i class="far fa-calendar-alt"></i> ${review.created_at}</span>
                                    </div>
                                    <div class="rating-stars">${stars}</div>
                                    <div class="review-comment">${review.comment || 'Không có nhận xét'}</div>
                                </div>
                            `;
                        });
                        reviewsList.innerHTML = reviewsHtml;
                    } else {
                        reviewsList.innerHTML = '<p style="text-align: center; padding: 20px;">Chưa có đánh giá nào cho sản phẩm này.</p>';
                    }
                } else {
                    reviewsList.innerHTML = `<p style="text-align: center; padding: 20px; color: var(--danger);"><i class="fas fa-exclamation-circle"></i> Có lỗi xảy ra: ${data.message}</p>`;
                }
            })
            .catch(error => {
                reviewsList.innerHTML = '<p style="text-align: center; padding: 20px; color: var(--danger);"><i class="fas fa-exclamation-circle"></i> Có lỗi xảy ra khi tải đánh giá</p>';
                console.error('Error:', error);
            });
    }

    function closeReviewsModal() {
        document.getElementById('reviewsModal').style.display = 'none';
    }

    // Đóng modal khi click bên ngoài
    window.onclick = function(event) {
        const modal = document.getElementById('reviewsModal');
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    }
</script>
</body>
</html>

<?php
$conn->close();
?>