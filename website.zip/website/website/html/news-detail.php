<?php
session_start();
$conn = new mysqli("localhost", "root", "", "website");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_GET['id'])) {
    header("Location: news.php");
    exit();
}

$news_id = (int)$_GET['id'];
$stmt = $conn->prepare("SELECT * FROM news WHERE id = ?");
$stmt->bind_param("i", $news_id);
$stmt->execute();
$news = $stmt->get_result()->fetch_assoc();

if (!$news) {
    header("Location: news.php");
    exit();
}

// Update view count
$stmt = $conn->prepare("UPDATE news SET views = views + 1 WHERE id = ?");
$stmt->bind_param("i", $news_id);
$stmt->execute();

// Get related news
$stmt = $conn->prepare("SELECT * FROM news WHERE id != ? ORDER BY created_at DESC LIMIT 3");
$stmt->bind_param("i", $news_id);
$stmt->execute();
$related_news = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($news['title']); ?> - Food and Furious</title>
    <link rel="icon" href="uploads/logo FnF.png">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/news.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Include your header here -->

    <div class="news-detail-container">
        <div class="news-detail-header">
            <div class="breadcrumb">
                <a href="index.php">Trang chủ</a>
                <span class="separator">/</span>
                <a href="news.php">Tin tức</a>
                <span class="separator">/</span>
                <span class="current"><?php echo htmlspecialchars($news['title']); ?></span>
            </div>

            <h1><?php echo htmlspecialchars($news['title']); ?></h1>
            
            <div class="news-meta">
                <span class="date">
                    <i class="far fa-calendar-alt"></i>
                    <?php echo date('d/m/Y', strtotime($news['created_at'])); ?>
                </span>
                <?php if (isset($news['author'])): ?>
                    <span class="author">
                        <i class="far fa-user"></i>
                        <?php echo htmlspecialchars($news['author']); ?>
                    </span>
                <?php endif; ?>
                <span class="views">
                    <i class="far fa-eye"></i>
                    <?php echo number_format($news['views']); ?> lượt xem
                </span>
            </div>
        </div>

        <div class="news-detail-content">
            <?php if ($news['image']): ?>
                <div class="feature-image">
                    <img src="<?php echo htmlspecialchars($news['image']); ?>" 
                         alt="<?php echo htmlspecialchars($news['title']); ?>">
                </div>
            <?php endif; ?>

            <div class="content">
                <?php echo nl2br(htmlspecialchars($news['content'])); ?>
            </div>

            <?php if (isset($news['tags'])): ?>
                <div class="news-tags">
                    <?php foreach (explode(',', $news['tags']) as $tag): ?>
                        <a href="news.php?tag=<?php echo urlencode(trim($tag)); ?>" class="tag">
                            #<?php echo htmlspecialchars(trim($tag)); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <?php if ($related_news->num_rows > 0): ?>
            <div class="related-news">
                <h2>Tin tức liên quan</h2>
                <div class="related-news-grid">
                    <?php while ($related = $related_news->fetch_assoc()): ?>
                        <div class="related-news-item">
                            <?php if ($related['image']): ?>
                                <img src="<?php echo htmlspecialchars($related['image']); ?>" 
                                     alt="<?php echo htmlspecialchars($related['title']); ?>">
                            <?php endif; ?>
                            <div class="related-news-content">
                                <h3>
                                    <a href="news-detail.php?id=<?php echo $related['id']; ?>">
                                        <?php echo htmlspecialchars($related['title']); ?>
                                    </a>
                                </h3>
                                <span class="date">
                                    <?php echo date('d/m/Y', strtotime($related['created_at'])); ?>
                                </span>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Include your footer here -->

    <script>
        // Social sharing functionality
        function shareFacebook() {
            window.open('https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(window.location.href));
        }
    </script>
</body>
</html>