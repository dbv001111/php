<?php
session_start();
$conn = new mysqli("localhost", "root", "", "website");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$items_per_page = 6;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $items_per_page;

$total_items = $conn->query("SELECT COUNT(*) as count FROM news")->fetch_assoc()['count'];
$total_pages = ceil($total_items / $items_per_page);

$result = $conn->query("SELECT * FROM news ORDER BY created_at DESC LIMIT $offset, $items_per_page");
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tin Tức - Food and Furious</title>
    <link rel="icon" href="uploads/logo FnF.png">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/taikhoan.css">
    <link rel="stylesheet" href="css/news.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <header>
        <img src="uploads/logo FnF.png" alt="Food and Furious" class="logo">
        <span class="brand-name-home">Food and Furious</span>
        <nav>
            <a href="index.php">Trang Chủ</a>
            <a href="menu.php">Thực Đơn</a>
            <a href="news.php">Tin Tức</a>
            <a href="giohang.php">Giỏ Hàng</a>
            <a href="#contact">Liên Hệ</a>          
        </nav>
        
        <div class="auth-buttons">
            <?php if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true): ?>
                <div class="account-icon-container">
                    <i class="account-icon" id="accountIcon">👤</i>
                    <div class="account-dropdown" id="accountDropdown">
                        <div class="account-dropdown-content">
                            <a href="#" id="accountInfoLink">Thông Tin Tài Khoản</a>
                            <a href="#" id="orderHistoryLink">Lịch Sử Đơn Hàng</a>
                            <a href="#" id="accountSettingsLink">Cài Đặt Tài Khoản</a>
                        </div>
                    </div>
                </div>
                <a href="login.php" class="login-btn" id="loginBtn">Đăng nhập để sử dụng</a>
                <a href="dangki.php" class="register-btn" id="registerBtn">Đăng ký</a>
            <?php else: ?>
                <div class="account-icon-container">
                    <i class="account-icon" id="accountIcon">👤</i>
                </div>
                <button type="button" class="logout-button" onclick="window.location.href='logout.php'">
                    Đăng xuất
                </button>
            <?php endif; ?>
        </div>
    </header>

    <div class="news-container">
        <h1>Tin Tức & Khuyến Mãi</h1>
        <div class="news-grid">
            <?php while($news = $result->fetch_assoc()): ?>
                <div class="news-item">
                    <?php if ($news['image']): ?>
                        <img src="<?php echo htmlspecialchars($news['image']); ?>" alt="<?php echo htmlspecialchars($news['title']); ?>" class="news-image">
                    <?php endif; ?>
                    <div class="news-content">
                        <h2><?php echo htmlspecialchars($news['title']); ?></h2>
                        <p><?php echo nl2br(htmlspecialchars($news['content'])); ?></p>
                        <div class="news-footer">
                            <span class="news-date">
                                <i class="far fa-calendar-alt"></i>
                                <?php echo date('d/m/Y', strtotime($news['created_at'])); ?>
                            </span>
                            <a href="#" class="read-more">Đọc thêm <i class="fas fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

        <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?page=<?php echo $i; ?>" class="<?php echo $page === $i ? 'active' : ''; ?>">
                    <?php echo $i; ?>
                </a>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
    </div>

    <footer id="contact">
        <div class="footer-container">
            <div class="footer-section">
                <h3>Thông Tin Liên Hệ</h3>
                <ul>
                    <li>Địa chỉ: số 48, ngõ 73 đường kim chung, yên vĩnh, hoài đức, hà nội</li>
                    <li>Số điện thoại: 0363102985</li>
                    <li>Email: 20221568@eaut.edu.vn</li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Chính Sách</h3>
                <ul>
                    <li>Chính sách bảo mật</li>
                    <li>Chính sách giao hàng</li>
                    <li>Chính sách đổi trả</li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Mạng Xã Hội</h3>
                <ul>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Instagram</a></li>
                    <li><a href="#">Twitter</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-copyright">
            <p>&copy; 2024 Food and Furious. All rights reserved.</p>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const accountIcon = document.getElementById('accountIcon');
            const accountDropdown = document.getElementById('accountDropdown');
            
            if (accountIcon && accountDropdown) {
                accountIcon.addEventListener('click', function(e) {
                    e.stopPropagation();
                    accountDropdown.style.display = accountDropdown.style.display === 'block' ? 'none' : 'block';
                });

                document.addEventListener('click', function() {
                    accountDropdown.style.display = 'none';
                });

                accountDropdown.addEventListener('click', function(e) {
                    e.stopPropagation();
                });
            }
        });
    </script>
</body>
</html>

<?php
$conn->close();
?>