<?php
session_start();
require_once 'db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Không đăng nhập'
    ]);
    exit();
}

if (isset($_GET['product_id'])) {
    $product_id = intval($_GET['product_id']);
    $user_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("SELECT rating, comment FROM reviews WHERE user_id = ? AND product_id = ?");
    $stmt->bind_param("ii", $user_id, $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($review = $result->fetch_assoc()) {
        echo json_encode([
            'status' => 'success',
            'rating' => $review['rating'],
            'comment' => $review['comment']
        ]);
    } else {
        echo json_encode([
            'status' => 'success',
            'rating' => null,
            'comment' => null
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Thiếu thông tin sản phẩm'
    ]);
}
?>