<?php
session_start();
require_once 'db_connect.php';

header('Content-Type: application/json');

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Vui lòng đăng nhập để đánh giá'
    ]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = intval($_POST['product_id']); 
    $user_id = $_SESSION['user_id'];
    $rating = intval($_POST['rating']);
    $comment = trim($_POST['comment'] ?? '');

    // Validate input
    if ($rating < 1 || $rating > 5) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Đánh giá không hợp lệ'
        ]);
        exit();
    }

    try {
        $conn->begin_transaction();

        // Kiểm tra đánh giá đã tồn tại
        $check_stmt = $conn->prepare("SELECT id FROM reviews WHERE user_id = ? AND product_id = ?");
        $check_stmt->bind_param("ii", $user_id, $product_id);
        $check_stmt->execute();
        $existing_review = $check_stmt->get_result()->fetch_assoc();

        if ($existing_review) {
            // Cập nhật đánh giá cũ
            $stmt = $conn->prepare("UPDATE reviews SET rating = ?, comment = ? WHERE user_id = ? AND product_id = ?");
            $stmt->bind_param("isii", $rating, $comment, $user_id, $product_id);
        } else {
            // Thêm đánh giá mới
            $stmt = $conn->prepare("INSERT INTO reviews (user_id, product_id, rating, comment) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiis", $user_id, $product_id, $rating, $comment);
        }
        $stmt->execute();

        // Cập nhật rating trung bình và số lượng đánh giá
        $update_query = "
            UPDATE products p 
            SET p.rating = (SELECT AVG(rating) FROM reviews WHERE product_id = ?),
                p.review_count = (SELECT COUNT(*) FROM reviews WHERE product_id = ?)
            WHERE p.id = ?
        ";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param("iii", $product_id, $product_id, $product_id);
        $update_stmt->execute();

        // Lấy thông tin mới
        $get_ratings = $conn->prepare("SELECT rating, review_count FROM products WHERE id = ?");
        $get_ratings->bind_param("i", $product_id);
        $get_ratings->execute();
        $new_ratings = $get_ratings->get_result()->fetch_assoc();

        $conn->commit();

        echo json_encode([
            'status' => 'success',
            'message' => 'Đánh giá thành công',
            'new_rating' => number_format($new_ratings['rating'], 1),
            'review_count' => $new_ratings['review_count']
        ]);

    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode([
            'status' => 'error',
            'message' => 'Có lỗi xảy ra: ' . $e->getMessage()
        ]);
    }
}
?>