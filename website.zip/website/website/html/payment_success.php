<?php
session_start();

// Check if the payment was successful
if (!isset($_SESSION['payment_success']) || $_SESSION['payment_success'] !== true) {
    header("Location: giohang.php");
    exit();
}

// Clear success flag after displaying the page
$_SESSION['payment_success'] = false;

// Get payment method
$method = isset($_GET['method']) ? $_GET['method'] : 'unknown';
$methodNames = [
    'bank' => 'Ngân hàng',
    'credit' => 'Thẻ tín dụng',
    'paypal' => 'PayPal'
];

$methodName = isset($methodNames[$method]) ? $methodNames[$method] : 'thanh toán trực tuyến';
$orderNumber = isset($_SESSION['last_order_id']) ? $_SESSION['last_order_id'] : 'N/A';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanh Toán Thành Công</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4CAF50;
            --secondary-color: #E8F5E9;
            --text-color: #333;
            --border-radius: 15px;
            --shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #E8F5E9 0%, #C8E6C9 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .success-container {
            max-width: 600px;
            width: 100%;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 40px;
            text-align: center;
            position: relative;
            overflow: hidden;
            animation: slideUpFade 0.8s ease-out;
        }
        
        @keyframes slideUpFade {
            from {
                transform: translateY(40px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .confetti {
            position: absolute;
            width: 10px;
            height: 10px;
            background: #f2d74e;
            animation: confetti 5s ease-in-out -2s infinite;
            transform-origin: 10px 10px;
            opacity: 0;
            z-index: -1;
        }
        
        .confetti:nth-child(1) {
            background: #f2d74e; top: 10%; left: 10%;
            animation-delay: 0;
        }
        
        .confetti:nth-child(2) {
            background: #95c3de; top: 20%; left: 80%;
            animation-delay: -0.5s;
        }
        
        .confetti:nth-child(3) {
            background: #ff9a91; top: 40%; left: 40%;
            animation-delay: -1s;
        }
        
        .confetti:nth-child(4) {
            background: #f2d74e; top: 60%; left: 70%;
            animation-delay: -1.5s;
        }
        
        .confetti:nth-child(5) {
            background: #95c3de; top: 80%; left: 30%;
            animation-delay: -2s;
        }
        
        @keyframes confetti {
            0% {
                transform: rotateZ(15deg) rotateY(0deg) translate(0, 0);
                opacity: 1;
            }
            25% {
                transform: rotateZ(5deg) rotateY(360deg) translate(-10px, 50px);
            }
            50% {
                transform: rotateZ(15deg) rotateY(720deg) translate(10px, 120px);
            }
            75% {
                transform: rotateZ(5deg) rotateY(1080deg) translate(-20px, 200px);
            }
            100% {
                transform: rotateZ(15deg) rotateY(1440deg) translate(0, 300px);
                opacity: 0;
            }
        }
        
        .success-icon {
            width: 100px;
            height: 100px;
            background: var(--primary-color);
            border-radius: 50%;
            margin: 0 auto 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% {
                box-shadow: 0 0 0 0 rgba(76, 175, 80, 0.6);
            }
            70% {
                box-shadow: 0 0 0 15px rgba(76, 175, 80, 0);
            }
            100% {
                box-shadow: 0 0 0 0 rgba(76, 175, 80, 0);
            }
        }
        
        .success-icon i {
            font-size: 50px;
            color: white;
        }
        
        .success-title {
            font-size: 32px;
            color: var(--primary-color);
            margin-bottom: 20px;
        }
        
        .success-text {
            font-size: 18px;
            color: var(--text-color);
            margin-bottom: 30px;
            line-height: 1.6;
        }
        
        .order-details {
            background: var(--secondary-color);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: left;
        }
        
        .detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            font-size: 16px;
            padding: 5px 0;
            border-bottom: 1px dashed #C8E6C9;
        }
        
        .detail-row:last-child {
            border-bottom: none;
        }
        
        .detail-label {
            font-weight: bold;
            color: var(--text-color);
        }
        
        .detail-value {
            color: #444;
        }
        
        .buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 20px;
        }
        
        .btn {
            padding: 12px 25px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .primary-btn {
            background: var(--primary-color);
            color: white;
        }
        
        .primary-btn:hover {
            background: #388E3C;
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
        }
        
        .secondary-btn {
            background: #F5F5F5;
            color: var(--text-color);
        }
        
        .secondary-btn:hover {
            background: #E0E0E0;
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        @media (max-width: 600px) {
            .success-container {
                padding: 30px 20px;
            }
            
            .buttons {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="success-container">
        <!-- Confetti effect -->
        <div class="confetti"></div>
        <div class="confetti"></div>
        <div class="confetti"></div>
        <div class="confetti"></div>
        <div class="confetti"></div>
        
        <div class="success-icon">
            <i class="fas fa-check"></i>
        </div>
        
        <h1 class="success-title">Thanh Toán Thành Công!</h1>
        
        <p class="success-text">
            Cảm ơn bạn đã đặt hàng. Đơn hàng của bạn đã được nhận và đang được xử lý.
            Bạn sẽ nhận được email xác nhận trong thời gian sớm nhất.
        </p>
        
        <div class="order-details">
            <div class="detail-row">
                <span class="detail-label">Mã đơn hàng:</span>
                <span class="detail-value"><?php echo htmlspecialchars($orderNumber); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Phương thức thanh toán:</span>
                <span class="detail-value"><?php echo htmlspecialchars($methodName); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Ngày đặt hàng:</span>
                <span class="detail-value"><?php echo date('d/m/Y H:i'); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Trạng thái:</span>
                <span class="detail-value" style="color: var(--primary-color); font-weight: bold;">
                    <i class="fas fa-check-circle"></i> Thanh toán thành công
                </span>
            </div>
        </div>
        
        <div class="buttons">
            <a href="index.php" class="btn primary-btn">
                <i class="fas fa-home"></i> Trang chủ
            </a>
            <a href="order_history.php" class="btn secondary-btn">
                <i class="fas fa-list"></i> Lịch sử đơn hàng
            </a>
        </div>
    </div>

    <script>
    // Extra animation effects
    document.addEventListener('DOMContentLoaded', function() {
        // Create more confetti dynamically
        const container = document.querySelector('.success-container');
        for (let i = 0; i < 30; i++) {
            const confetti = document.createElement('div');
            confetti.className = 'confetti';
            confetti.style.left = Math.random() * 100 + '%';
            confetti.style.top = Math.random() * 100 + '%';
            confetti.style.background = ['#f2d74e', '#95c3de', '#ff9a91', '#f49ac1', '#8fd9a8'][Math.floor(Math.random() * 5)];
            confetti.style.animationDelay = Math.random() * 5 + 's';
            container.appendChild(confetti);
        }
    });
    </script>
</body>
</html>