<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['update'])) {
            $productId = $_POST['product_id'];
            if (!isset($_SESSION['quantity'][$productId])) {
                $_SESSION['quantity'][$productId] = 1;
            }
            if ($_POST['update'] === 'increase') {
                $_SESSION['quantity'][$productId]++;
            } elseif ($_POST['update'] === 'decrease' && $_SESSION['quantity'][$productId] > 1) {
                $_SESSION['quantity'][$productId]--;
            }
        }

        if (isset($_POST['remove'])) {
            $productId = $_POST['product_id'];
            unset($_SESSION['cart'][array_search($productId, $_SESSION['cart'])]);
            unset($_SESSION['quantity'][$productId]);
        }

        // Xử lý thêm sản phẩm vào giỏ hàng
        if (isset($_POST['add_to_cart'])) {
            $productId = $_POST['product_id'];
            if (!isset($_SESSION['cart'])) {
                $_SESSION['cart'] = [];
            }
            if (!in_array($productId, $_SESSION['cart'])) {
                $_SESSION['cart'][] = $productId;
                $_SESSION['quantity'][$productId] = 1; // Thiết lập số lượng mặc định là 1
            }
        }

        // Trong phần xử lý POST request
        if (isset($_POST['payment_method'])) {
            if (!isset($_SESSION['user_id'])) {
                echo "<script>alert('Vui lòng đăng nhập để thanh toán!'); window.location.href='login.php';</script>";
                exit();
            }

            // Tính tổng tiền
            $total = 0;
            foreach ($_SESSION['cart'] as $product_id) {
                if (isset($_SESSION['quantity'][$product_id])) {
                    $stmt = $pdo->prepare("SELECT price FROM products WHERE id = ?");
                    $stmt->execute([$product_id]);
                    $product = $stmt->fetch();
                    $total += ($product['price'] * $_SESSION['quantity'][$product_id]);
                }
            }

            $_SESSION['total_amount'] = $total;
            
            $paymentMethod = $_POST['payment_method'];
            switch($paymentMethod) {
                case 'credit_card':
                    header('Location: credit.php');
                    break;
                case 'bank':
                    header('Location: bank.php');
                    break;
                case 'paypal':
                    header('Location: paypal.php');
                    break;
                default:
                    echo "<script>alert('Phương thức thanh toán không hợp lệ!');</script>";
            }
            exit();
        }
    }
    ?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Giỏ hàng</title>
        <link rel="stylesheet" href="css/giohang.css">
    </head>
    <body>
        <div class="container">
            <header><h1>Giỏ hàng của bạn</h1></header>
            <div class="navigation">
                 <a href="index.php" class="nav-button">Trang chủ</a>
                <a href="menu.php" class="nav-button continue-shopping">Tiếp tục mua sắm</a>
            </div>

            <?php
            if (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0) {
                echo '<p>Giỏ hàng của bạn đang trống.</p>';
            } else {
                $placeholders = rtrim(str_repeat('?,', count($_SESSION['cart'])), ',');
                $stmt = $pdo->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
                $stmt->execute(array_values($_SESSION['cart']));

                echo '<div class="cart-items">';
                $total = 0;

                while ($row = $stmt->fetch()) {
                    $productId = htmlspecialchars($row['id']);
                    $productName = htmlspecialchars($row['name']);
                    $productPrice = number_format($row['price']);
                    $quantity = isset($_SESSION['quantity'][$productId]) ? $_SESSION['quantity'][$productId] : 1;
                    $subtotal = $row['price'] * $quantity;
                    $total += $subtotal;

                    echo '<div class="cart-item">';
                    echo '<img src="' . htmlspecialchars($row['image']) . '" alt="' . $productName . '" class="product-image">';
                    echo '<h2>' . $productName . '</h2>';
                    echo '<p class="price">' . $productPrice . '₫</p>';
                    echo '<div class="quantity-controls">';
                    echo '<form method="POST" action="giohang.php" style="display:inline;">';
                    echo '<input type="hidden" name="product_id" value="' . $productId . '">';
                    echo '<button type="submit" name="update" value="decrease" class="quantity-button">-</button>';
                    echo '<span class="quantity-display">' . $quantity . '</span>';
                    echo '<button type="submit" name="update" value="increase" class="quantity-button">+</button>';
                    echo '</form>';
                    echo '<form method="POST" action="giohang.php" style="display:inline;">';
                    echo '<input type="hidden" name="product_id" value="' . $productId . '">';
                    echo '<button type="submit" name="remove" value="remove" class="remove-button">Xóa</button>';
                    echo '</form>';
                    echo '</div>';
                    echo '</div>';
                }

                echo '</div>';
                echo '<div class="cart-total">';
                echo '<h3>Tổng cộng: ' . number_format($total) . '₫</h3>';
                echo '</div>';

                echo '<div class="payment-section">';
                echo '<h3>Chọn phương thức thanh toán</h3>';
                echo '<form method="POST" action="">';
                echo '<div class="payment-methods">';
                echo '<label class="payment-option"><input type="radio" name="payment_method" value="credit_card" required> Thẻ tín dụng</label>';
                echo '<label class="payment-option"><input type="radio" name="payment_method" value="bank"> Ngân hàng</label>';
                echo '<label class="payment-option"><input type="radio" name="payment_method" value="paypal"> PayPal</label>';
                echo '</div>';
                echo '<button type="submit" class="payment-btn">Thanh toán</button>';
                echo '</form>';
                echo '</div>';
                
                // Nút kiểm tra trạng thái đơn hàng
                if (isset($_SESSION['last_order_id'])) {
                    echo '<button id="checkOrderStatusBtn" class="status-btn" onclick="checkOrderStatus()">Kiểm tra trạng thái đơn hàng</button>';
                }
            }
            ?>
        </div>

        <div id="statusModal" class="modal">
            <div class="modal-content">
                <span class="close" onclick="closeModal()">&times;</span>
                <h2>Trạng thái đơn hàng</h2>
                <div id="orderStatusContent"></div>
            </div>
        </div>

        <script>
        function checkOrderStatus() {
            var modal = document.getElementById("statusModal");
            var span = document.getElementsByClassName("close")[0];
            
            fetch("check_order_status.php")
                .then(response => response.json())
                .then(data => {
                    if (data.status === "success") {
                        const orderDetails = `
                            <div class="order-details" style="padding: 20px;">
                                <p><strong>Mã đơn hàng:</strong> ${data.order_id}</p>
                                <p><strong>Phương thức thanh toán:</strong> ${data.payment_method}</p>
                                <p><strong>Tổng tiền:</strong> ${data.total_amount}</p>
                                <p><strong>Địa chỉ giao hàng:</strong> ${data.shipping_address}</p>
                                <p><strong>Trạng thái thanh toán:</strong> ${data.payment_status}</p>
                                <p><strong>Ngày đặt hàng:</strong> ${data.order_date}</p>
                            </div>
                        `;
                        document.getElementById("orderStatusContent").innerHTML = orderDetails;
                    } else {
                        document.getElementById("orderStatusContent").innerHTML = 
                            `<p style="color: red;">${data.message}</p>`;
                    }
                    modal.style.display = "block";
                })
                .catch(error => {
                    document.getElementById("orderStatusContent").innerHTML = 
                        `<p style="color: red;">Có lỗi xảy ra khi kiểm tra trạng thái đơn hàng</p>`;
                    modal.style.display = "block";
                });

            span.onclick = function() {
                modal.style.display = "none";
            }

            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            }
        }

        function closeModal() {
            document.getElementById("statusModal").style.display = "none";
        }
        </script>
    </body>
    </html>
    <?php
} catch(PDOException $e) {
    echo "Kết nối thất bại: " . $e->getMessage();
}
?>